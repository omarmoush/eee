// controllers/orderController.js
const mongoose = require('mongoose');
const Order = require('../models/Order');
const MenuItem = require('../models/MenuItems');

// Create new order
const createOrder = async (req, res) => {
  try {
    console.log('Create order request received:', req.body);
    
    const { user_id, menu_items, delivery_address, payment_method, special_instructions, order_type, pickup_time, contact_phone, reservation_id, table_number, total_price } = req.body;

    // Validate required fields
    if (!user_id || !menu_items || !Array.isArray(menu_items) || menu_items.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'user_id and menu_items (non-empty array) are required'
      });
    }

    // Fetch actual menu item prices from database
    const orderMenuItems = await Promise.all(
      menu_items.map(async (item) => {
        const menuItem = await MenuItem.findById(item.menu_item_id);
        if (!menuItem) {
          throw new Error(`Menu item ${item.menu_item_id} not found`);
        }
        return {
          menu_item: item.menu_item_id,
          quantity: item.quantity,
          price: menuItem.price
        };
      })
    );

    // Calculate total from actual prices
    const calculatedTotal = orderMenuItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    const order = new Order({
      user_id,
      menu_items: orderMenuItems,
      total_price: total_price || calculatedTotal,
      delivery_address,
      payment_method: payment_method || 'cash',
      special_instructions,
      status: 'pending',
      estimated_delivery_time: new Date(Date.now() + 45 * 60000)
    });

    await order.save();

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: order
    });

  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({
      success: false,
      message: 'Error creating order',
      error: error.message
    });
  }
};

// Get order details
const getOrderDetails = async (req, res) => {
  try {
    const { id } = req.params;
    const order = await Order.findById(id)
      .populate('user_id', 'name email phone')
      .populate('menu_items.menu_item', 'name price image');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });

  } catch (error) {
    console.error('Error fetching order details:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching order details',
      error: error.message
    });
  }
};

// Update order status
const updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

  const order = await Order.findByIdAndUpdate(
    id,
    { status },
    { new: true, runValidators: true }
  );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Order status updated successfully',
      data: order
    });

  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating order status',
      error: error.message
    });
  }
};

// Get all orders (admin)
const getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate('user_id', 'name email phone')
      .populate('menu_items.menu_item', 'name price image')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: orders
    });

  } catch (error) {
    console.error('Error fetching all orders:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching orders',
      error: error.message
    });
  }
};

// List user's orders
const getUserOrders = async (req, res) => {
  try {
    const { user_id } = req.params;

    if (!mongoose.isValidObjectId(user_id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid user id'
      });
    }

    const orders = await Order.find({ user_id: new mongoose.Types.ObjectId(user_id) })
      .populate('menu_items.menu_item', 'name price image')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: orders
    });

  } catch (error) {
    console.error('Error fetching user orders:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching user orders',
      error: error.message
    });
  }
};

module.exports = {
  createOrder,
  getOrderDetails,
  updateOrderStatus,
  getAllOrders,
  getUserOrders
};