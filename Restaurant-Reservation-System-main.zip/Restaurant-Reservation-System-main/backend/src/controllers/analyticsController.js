const mongoose = require('mongoose');
const Review = require('../models/Review');
const User = require('../models/User');
const Reservation = require('../models/Reservation');
const Order = require('../models/Order');

const analyticsController = {
    getAnalytics: async (req, res) => {
        try {
            // Only admins can access analytics
            if (req.user.role !== 'Admin') {
                return res.status(403).json({ message: 'Admin access required' });
            }

            // Get total users
            const totalUsers = await User.countDocuments();
            const totalCustomers = await User.countDocuments({ role: 'Customer' });
            const totalAdmins = await User.countDocuments({ role: 'Admin' });

            // Get reviews analytics
            const totalReviews = await Review.countDocuments();
            const avgRatingResult = await Review.aggregate([
                {
                    $group: {
                        _id: null,
                        avgRating: { $avg: '$rating' }
                    }
                }
            ]);
            const avgRating = avgRatingResult.length > 0 ? avgRatingResult[0].avgRating : 0;

            // Rating distribution
            const ratingDistribution = await Review.aggregate([
                {
                    $group: {
                        _id: '$rating',
                        count: { $sum: 1 }
                    }
                },
                { $sort: { _id: 1 } }
            ]);

            // Recent reviews (last 30 days)
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
            const recentReviews = await Review.countDocuments({
                createdAt: { $gte: thirtyDaysAgo }
            });

            // User registration trend (last 30 days)
            const recentUsers = await User.countDocuments({
                createdAt: { $gte: thirtyDaysAgo }
            });

            // Reservations analytics (overall and last 30 days)
            const totalReservations = await Reservation.countDocuments();
            const recentReservations = await Reservation.countDocuments({
                createdAt: { $gte: thirtyDaysAgo }
            });

            // Orders analytics: total orders, recent orders, and revenue
            const totalOrders = await Order.countDocuments();
            const recentOrders = await Order.countDocuments({
                createdAt: { $gte: thirtyDaysAgo }
            });
            const revenueResult = await Order.aggregate([
                {
                    $group: {
                        _id: null,
                        totalRevenue: { $sum: '$total_price' }
                    }
                }
            ]);
            const totalRevenue =
                revenueResult.length > 0 ? revenueResult[0].totalRevenue : 0;

            const analytics = {
                users: {
                    total: totalUsers,
                    customers: totalCustomers,
                    admins: totalAdmins,
                    recentRegistrations: recentUsers
                },
                reviews: {
                    total: totalReviews,
                    averageRating: parseFloat(avgRating.toFixed(2)),
                    recentReviews: recentReviews,
                    ratingDistribution: ratingDistribution
                },
                reservations: {
                    total: totalReservations,
                    recent: recentReservations
                },
                orders: {
                    total: totalOrders,
                    recent: recentOrders,
                    totalRevenue: totalRevenue
                }
            };

            res.status(200).json({
                message: 'Analytics data retrieved successfully',
                analytics
            });
        } catch (error) {
            console.error('Error fetching analytics:', error);
            res.status(500).json({ message: 'Server error while fetching analytics' });
        }
    }
};

module.exports = analyticsController;