const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const loginController = {
    loginUser: async (req, res) => {
        try {
            const { email, phone, password } = req.body;

            // Require password
            if (!password || typeof password !== 'string' || !password.trim()) {
                return res
                    .status(400)
                    .json({ message: 'Password is required (  •̀ - •́  )' });
            }

            // Require exactly one of email or phone
            const hasEmail = typeof email === 'string' && email.trim() !== '';
            const hasPhone = typeof phone === 'string' && phone.trim() !== '';

            if ((!hasEmail && !hasPhone) || (hasEmail && hasPhone)) {
                return res
                    .status(400)
                    .json({ message: 'Provide either email OR phone, not both (  •̀ - •́  )' });
            }

            let query;
            if (hasEmail) {
                query = { email: email.toLowerCase().trim() };
            } else {
                query = { phone: phone.trim() };
            }

            const user = await User.findOne(query);

            if (!user) {
                return res
                    .status(401)
                    .json({ message: 'Invalid credentials! •︵•' });
            }

            const isPasswordMatch = await user.comparePassword(password);
            if (!isPasswordMatch) {
                return res
                    .status(401)
                    .json({ message: 'Invalid credentials! •︵•' });
            }

            const payload = {
                userId: user._id,
                role: user.role
            };
            const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

            res.status(200).json({
                message: 'Login successful ᵔ ᵕ ᵔ',
                token,
                user: {
                    id: user._id,
                    name: user.name,
                    email: user.email,
                    phone: user.phone,
                    role: user.role
                }
            });
        } catch (error) {
            console.error('Error in user login (._.):', error);
            res.status(500).json({ message: 'Server error during login (._.)' });
        }
    }
};

module.exports = loginController;