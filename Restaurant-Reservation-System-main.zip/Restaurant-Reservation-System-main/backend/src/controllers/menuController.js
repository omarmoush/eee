const MenuItem = require("../models/MenuItems.js");

// all menu items
const getAllMenuItems = async (req, res) => {
    try {
      const items = await MenuItem.find();
      res.status(200).json(items);
    } catch (err) {
      console.error("Error fetching menu items:", err);
      res.status(500).json({ error: "Server error" });
    }
    console.log("Using collection:", MenuItem.collection.name);
  };

// creates new item
const createMenuItem = async (req, res) => {
    try {
      const item = await MenuItem.create(req.body);
      res.status(201).json(item);
    } catch (err) {
      console.error("Error creating menu item:", err);
      res.status(400).json({ error: err.message });
    }
  };
// updates item
const updateMenuItem = async (req, res) => {
    try {
      const item = await MenuItem.findByIdAndUpdate(req.params.id, req.body, {
        new: true
      });
      res.status(200).json(item);
    } catch (err) {
      console.error("Error updating menu item:", err);
      res.status(400).json({ error: err.message });
    }
  };

// deletes item
const deleteMenuItem = async (req, res) => {
    try {
      await MenuItem.findByIdAndDelete(req.params.id);
      res.status(200).json({ message: "Menu item deleted" });
    } catch (err) {
      console.error("Error deleting menu item:", err);
      res.status(400).json({ error: err.message });
    }
  };

  module.exports = {
    getAllMenuItems,
    createMenuItem,
    updateMenuItem,
    deleteMenuItem
  };
