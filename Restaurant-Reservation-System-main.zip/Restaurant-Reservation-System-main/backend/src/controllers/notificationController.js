const mongoose = require('mongoose');
const Notification = require('../models/Notification');
const User = require('../models/User');
const jwt = require('jsonwebtoken');


const notificationController = {
    // Get all notifications for a user
    getUserNotifications: async (req, res) => {
        try {
        const userId = req.params.user_id;

        // Validate ObjectId format
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Invalid user ID format' });
        }

        // Check permissions
        const currentUserId = req.user.userId;
        const isAdmin = req.user.role === 'Admin';

        if (!isAdmin && currentUserId !== userId) {
            return res.status(403).json({ message: 'Access denied' });
        }

        // Fetch notifications
        const notifications = await Notification.find({ user_id: userId })
            .sort({ createdAt: -1 });

        res.status(200).json({
            message: 'Notifications retrieved successfully',
            notifications
        });
        } catch (error) {
        console.error('Error fetching notifications:', error);
        res.status(500).json({ message: 'Server error while fetching notifications' });
        }
    },
    // Send new notification (Admin only)
    createNotification: async (req, res) => {
    try {
        // Admin only
        if (!req.user || req.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Only admins can create notifications' })
        }

        const { email, title, message, type } = req.body

        if (!email || !title || !message) {
        return res.status(400).json({ message: 'Email, title, and message are required' })
        }

        // Find user by email
        const user = await User.findOne({ email })

        if (!user) {
        return res.status(404).json({ message: 'User not found for this email' })
        }

        const notification = await Notification.create({
        user_id: user._id,
        title,
        message,
        type
        })

        res.status(201).json({
        message: 'Notification created successfully',
        notification
        })
    } catch (error) {
        console.error('Error creating notification:', error)
        res.status(500).json({ message: 'Server error while creating notification' })
    }
    },

    // Mark notification as read
    markAsRead: async (req, res) => {
        try {
            const notificationId = req.params.id;

            if (!mongoose.Types.ObjectId.isValid(notificationId)) {
                return res.status(400).json({ message: 'Invalid notification ID format' });
            }
            
            const notification = await Notification.findById(notificationId);
            if (!notification) {
                return res.status(404).json({ message: 'Notification not found' });
            }

            const currentUserId = req.user && req.user.userId ? req.user.userId.toString() : null;
            const isAdmin = req.user && req.user.role === 'Admin';

            if (!currentUserId || (currentUserId !== notification.user_id.toString() && !isAdmin)) {
                return res.status(403).json({ message: 'Access denied' });
            }

            notification.read = true;
            await notification.save();

            res.status(200).json({ 
                message: 'Notification marked as read', 
                notification 
            });
        } catch (error) {
            console.error('Error marking notification as read:', error);
            res.status(500).json({ message: 'Server error while updating notification' });
        }
    }
};

module.exports = notificationController;