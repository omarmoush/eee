const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const registerController = {
    createUser: async (req, res) => {
        try {
        const{name, email, phone, password, role} =  req.body;

        if(!name || !email || !password){
            return res.status(400).json({message: 'Name, email, and password are required!'});
        }

        // Check for existing user by email and phone (if provided)
        const existingQuery = [{email}];
        if(phone) existingQuery.push({phone});
        const existingUser = await User.findOne({$or: existingQuery});
        if(existingUser){
            if(existingUser.email === email){
                return res.status(409).json({message: 'User with this email already exists!'});
            } else {
                return res.status(409).json({message: 'User with this phone number already exists!'});
            }
        }

        const newUser = new User({name, email, phone, password, role});
        await newUser.save();

        const payload = {
            userId: newUser._id,
            role: newUser.role
        };
        const token = jwt.sign(payload, process.env.JWT_SECRET, {expiresIn: '1h'});

        res.status(201).json({message: 'User registered ᵔ ᵕ ᵔ', token, user:
            {id: newUser._id,
            name: newUser.name,
            email: newUser.email,
            phone: newUser.phone,
            role: newUser.role}
        });

    } catch (error) {
        console.error('Error in user registration ˙◠˙:', error);
        res.status(500).json({message: 'Server error during registration ˙◠˙'});
}
}};

module.exports = registerController;
