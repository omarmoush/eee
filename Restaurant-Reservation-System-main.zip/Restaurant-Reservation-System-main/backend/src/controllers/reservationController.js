const Reservation = require('../models/Reservation');

// POST / - Create a new reservation
const createReservation = async (req, res) => {
  try {
    const { user_id, date, time, partySize, specialRequests, contactPhone, contactEmail } = req.body;

    // Validate required fields
    if (!user_id || !date || !time || !partySize || !contactPhone || !contactEmail) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: user_id, date, time, partySize, contactPhone, contactEmail'
      });
    }

    // Create new reservation
    const reservation = new Reservation({
      user_id,
      date,
      time,
      partySize,
      specialRequests: specialRequests || '',
      contactPhone,
      contactEmail
    });

    await reservation.save();

    res.status(201).json({
      success: true,
      message: 'Reservation created successfully',
      data: reservation
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating reservation',
      error: error.message
    });
  }
};

// GET /:id - Get a reservation by ID
const getReservationById = async (req, res) => {
  try {
    const { id } = req.params;

    const reservation = await Reservation.findById(id).populate('user_id', 'name email');

    if (!reservation) {
      return res.status(404).json({
        success: false,
        message: 'Reservation not found'
      });
    }

    res.status(200).json({
      success: true,
      data: reservation
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving reservation',
      error: error.message
    });
  }
};

// PUT /:id - Update or cancel a reservation
const updateReservation = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Find the reservation
    const reservation = await Reservation.findById(id);

    if (!reservation) {
      return res.status(404).json({
        success: false,
        message: 'Reservation not found'
      });
    }

    // Update allowed fields
    const allowedUpdates = ['date', 'time', 'partySize', 'status', 'specialRequests', 'contactPhone', 'contactEmail'];
    const updates = Object.keys(updateData);
    const isValidOperation = updates.every(update => allowedUpdates.includes(update));

    if (!isValidOperation) {
      return res.status(400).json({
        success: false,
        message: 'Invalid update fields'
      });
    }

    // Apply updates
    updates.forEach(update => {
      reservation[update] = updateData[update];
    });

    await reservation.save();

    res.status(200).json({
      success: true,
      message: 'Reservation updated successfully',
      data: reservation
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error updating reservation',
      error: error.message
    });
  }
};

// GET /user/:user_id - Get all reservations for a specific user
const getUserReservations = async (req, res) => {
  try {
    const { user_id } = req.params;

    const reservations = await Reservation.find({ user_id })
      .populate('user_id', 'name email')
      .sort({ createdAt: -1 }); // Most recent first

    res.status(200).json({
      success: true,
      count: reservations.length,
      data: reservations
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving user reservations',
      error: error.message
    });
  }
};

// GET / - Admin: Get all reservations
const getAllReservations = async (req, res) => {
  try {
    const reservations = await Reservation.find()
      .populate('user_id', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: reservations.length,
      data: reservations
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving reservations',
      error: error.message
    });
  }
};

module.exports = {
  createReservation,
  getReservationById,
  updateReservation,
  getUserReservations
  ,
  getAllReservations
};

