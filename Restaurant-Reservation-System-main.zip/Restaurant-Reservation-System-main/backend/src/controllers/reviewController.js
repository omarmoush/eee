const Review = require('../models/Review');
const ReviewFactory = require('../factories/ReviewFactory');

// Submit a review
exports.createReview = async (req, res) => {
  try {
    const { reservation_id, rating, comment } = req.body;

    if (!reservation_id || !rating) {
      return res.status(400).json({ error: 'reservation_id and rating are required' });
    }

    const review = await ReviewFactory.createReview({
      user_id: req.user.userId,
      reservation_id,
      rating,
      comment
    });

    res.status(201).json(review);
  } catch (err) {
    console.error('Create review error:', err);
    res.status(500).json({ error: err.message });
  }
};

// Edit a review (owner only)
exports.updateReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found' });

    const reviewOwnerId = review.user_id ? review.user_id.toString() : null;
    const currentUserId = req.user && req.user.userId ? req.user.userId.toString() : null;

    if (!currentUserId || currentUserId !== reviewOwnerId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const { rating, comment } = req.body;
    if (rating !== undefined) review.rating = rating;
    if (comment !== undefined) review.comment = comment;

    await review.save();
    res.json(review);
  } catch (err) {
    console.error('Update review error:', err);
    res.status(500).json({ error: err.message });
  }
};

// Delete a review (owner only)
exports.deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found' });

    const reviewOwnerId = review.user_id ? review.user_id.toString() : null;
    const currentUserId = req.user && req.user.userId ? req.user.userId.toString() : null;
    if (!currentUserId || currentUserId !== reviewOwnerId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    await Review.findByIdAndDelete(req.params.id);
    res.json({ message: 'Review deleted' });
  } catch (err) {
    console.error('Delete review error:', err);
    res.status(500).json({ error: err.message });
  }
};

// List reviews (public)
exports.listReviews = async (req, res) => {
  try {
    const reviews = await Review.find({})
      .populate('user_id', 'name')
      .populate('reservation_id', 'date time partySize')
      .sort({ createdAt: -1 });
    res.json(reviews);
  } catch (err) {
    console.error('List reviews error:', err);
    res.status(500).json({ error: err.message });
  }
};
