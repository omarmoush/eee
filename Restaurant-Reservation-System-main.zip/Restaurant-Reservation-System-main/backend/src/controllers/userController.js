const mongoose = require('mongoose');
const User = require('../models/User');
const authenticate = require('../middleware/authenticationMiddleware');

const userController = {
    getUserProfile: async (req, res) => {
        try {
            const userId = req.user.userId;
            const user = await User.findById(userId).select('-password');
            if (!user) {
                return res.status(401).json({ message: 'Unauthorized' });
            }
            const userData = {
                userId: user._id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role
            };
            res.status(200).json({ message: 'User profile fetched successfully', user: userData });
        } catch (error) {
            console.error('Error fetching user profile:', error);
            res.status(500).json({ message: 'Server error while fetching profile' });
        }
    },

    updateUserProfile: async (req, res) => {
        try {
            const userId = req.user.userId;
            const { name, email, phone, password} = req.body;
            const user = await User.findById(userId);
            if (!user) {
                return res.status(404).json({ message: 'User not found T_T' });
            }

            user.name = name || user.name;
            user.email = email || user.email;
            user.phone = phone || user.phone;

            if(password){
                user.password = password;
            }
            

            await user.save();
            res.status(200).json({ message: 'Profile updated successfully ◝(ᵔᗜᵔ)◜', user: {
                userId: user._id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role
            } });
        }
        catch (error) {
            console.error('Error updating user profile:', error);
            res.status(500).json({ message: 'Server error while updating profile T_T' });
        }
    }
};

module.exports = userController;
