const Review = require('../models/Review');

class ReviewFactory {
  /**
   * Factory method to create a review
   * @param {Object} data - The review data
   * @returns {Promise<Document>} The created review document
   */
  static async createReview(data) {
    // Here you could add logic to create different types of reviews
    // For now, we just create a standard Review
    const review = new Review(data);
    return await review.save();
  }
}

module.exports = ReviewFactory;
