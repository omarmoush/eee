const jwt = require('jsonwebtoken');
const User = require('../models/User');

const authenticationMiddleware = async (req, res, next) => {
    let token;

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
    } 
   
    else if (req.cookies && req.cookies.token) {
        token = req.cookies.token;
    } 
   
    else if (req.body && req.body.token) {
        token = req.body.token;
    }

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized (•̀⤙•́ )' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.userId);

        if (!user) {
            return res.status(401).json({ message: 'User not found >o<' });
        }

        req.user = {
            userId: user._id,
            name: user.name,
            email: user.email,
            role: user.role
        };

        next();
    } catch (error) {
        console.error('Authentication error >o<:', error);
        return res.status(401).json({ message: 'Invalid or expired token >o<' });
    }
};

module.exports = authenticationMiddleware;
