// middleware/auth.js
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // waiting on user model

// Check if user is logged in
exports.isAuthenticated = async (req, res, next) => {
    let token;
  try {
    const authHeader = req.headers.authorization;;
    if (authHeader && authHeader.startsWith('Bearer ')){
        token = authHeader.split(' ')[1];
    }

    else if (req.cookies && req.cookies.token){
        token = req.cookies.token;
    } 

    else {
        return res.status(401).json({ error: 'No token, authorization denied' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ error: 'User not found' });

    req.user = {
        userId: user._id,
        name: user.name,
        email: user.email,
        role: user.role
    }; // attach user to request
    next();
  } catch (err) {
    console.error('Authorization error:', err);
    res.status(401).json({ error: 'Token is not valid' });
  }
};

exports.authorizedRoles = (allowedRoles) => {
    return (req, res, next) => {
        if(!req.user){
            return res.status(401).json({ error: 'User not authenticated' });
        }
        if(!allowedRoles.includes(req.user.role)){
            return res.status(403).json({ error: `Role (${req.user.role}) not authorized to access this resource` });
        }
        next();
    }
};
