import mongoose from "mongoose";

const menuSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  category: String,
  available: Boolean
});

// third argument = EXACT collection name in MongoDB
export default mongoose.model("Menu", menuSchema, "menu");
