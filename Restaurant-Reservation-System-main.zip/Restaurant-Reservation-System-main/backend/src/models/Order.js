// models/Order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema(
  {
    user_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    menu_items: [{
      menu_item: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MenuItem',
        required: true
      },
      quantity: {
        type: Number,
        required: true,
        min: 1
      },
      price: {
        type: Number,
        required: true,
        min: 0
      }
    }],
    total_price: {
      type: Number,
      required: true,
      min: 0
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'preparing', 'ready', 'out-for-delivery', 'delivered', 'cancelled'],
      default: 'pending'
    },
    payment_status: {
      type: String,
      enum: ['pending', 'paid', 'failed', 'refunded'],
      default: 'pending'
    },
    payment_method: {
      type: String,
      enum: ['card', 'cash', 'online'],
      default: 'cash'
    },
    delivery_address: {
      street: String,
      city: String,
      state: String,
      zipCode: String
    },
    estimated_delivery_time: {
      type: Date
    },
    special_instructions: {
      type: String,
      maxlength: 500
    }
  },
  { timestamps: true }
);

// Add index for better query performance
orderSchema.index({ user_id: 1, createdAt: -1 });
orderSchema.index({ status: 1 });

const Order = mongoose.models.Order || mongoose.model('Order', orderSchema);

module.exports = Order;