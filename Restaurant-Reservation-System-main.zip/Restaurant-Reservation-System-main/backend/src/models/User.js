const mongoose = require('mongoose');
const { Schema } = mongoose;
const bcrypt = require('bcryptjs');
const saltRounds = 10;

const userSchema = new Schema({
    name:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    phone:{
        type: String,
        required: false,
        unique: true,
        sparse: true,
        trim: true
    },
    password:{
        type: String,
        required: [true, 'Password is required']
    },
    role:{
        type: String,
        enum: ['Customer', 'Admin'],
        default: 'Customer'
    },
},
    { timestamps: true }
);

userSchema.pre('save', async function () {
    if (!this.isModified('password')) return;

    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
});



userSchema.methods.comparePassword = async function (writtenPassword) {
    return await bcrypt.compare(writtenPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);

