// routes/orderRoutes.js
const express = require('express');
const router = express.Router();
const {
  createOrder,
  getOrderDetails,
  updateOrderStatus,
  getAllOrders,
  getUserOrders,
} = require('../controllers/OrderController');

// POST /api/v1/orders - Create new order
router.post('/', createOrder);

// GET /api/v1/orders/all - Get all orders (admin)
router.get('/all', getAllOrders);

// GET /api/v1/orders/user/:user_id - List user's orders
router.get('/user/:user_id', getUserOrders);

// GET /api/v1/orders/:id - Get order details
router.get('/:id', getOrderDetails);

// PUT /api/v1/orders/:id - Update order status
router.put('/:id', updateOrderStatus);



module.exports = router;