const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
const analyticsController = require('../controllers/analyticsController');
const { isAuthenticated, authorizedRoles } = require('../middleware/authorizationMiddleware');
const authenticate = require('../middleware/authenticationMiddleware');


// Analytics routes
router.get('/analytics', authenticate, authorizedRoles(['Admin']), analyticsController.getAnalytics); //works

// Notification routes
router.get('/:user_id', authenticate, notificationController.getUserNotifications); //only works with admin
router.post('/', authenticate, authorizedRoles(['Admin']), notificationController.createNotification); //works must user actual userID
router.put('/:id', authenticate, notificationController.markAsRead); 



module.exports = router;