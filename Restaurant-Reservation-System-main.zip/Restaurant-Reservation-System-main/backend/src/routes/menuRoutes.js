const express = require("express");
const {
    getAllMenuItems,
    createMenuItem,
    updateMenuItem,
    deleteMenuItem
} = require("../controllers/menuController.js");
const authenticationMiddleware = require("../middleware/authenticationMiddleware.js");
const { authorizedRoles } = require("../middleware/authorizationMiddleware.js");

const router = express.Router();

// get all menu items
router.get("/", getAllMenuItems);

// admin only/create menu item
router.post("/", authenticationMiddleware, authorizedRoles(['Admin']), createMenuItem);

// update menu item (admin only)
router.put("/:id", authenticationMiddleware, authorizedRoles(['Admin']), updateMenuItem);

// delete menu item (admin only)
router.delete("/:id", authenticationMiddleware, authorizedRoles(['Admin']), deleteMenuItem);

module.exports = router;
 