const express = require('express');
const router = express.Router();
const {
  createReservation,
  getReservationById,
  updateReservation,
  getUserReservations,
  getAllReservations
} = require('../controllers/reservationController');
const authenticate = require('../middleware/authenticationMiddleware');
const { authorizedRoles } = require('../middleware/authorizationMiddleware');

// POST /api/v1/reservations - Create a new reservation
router.post('/', createReservation);

// GET /api/v1/reservations - Admin only: Get all reservations (most recent first)
router.get('/', authenticate, authorizedRoles(['Admin']), getAllReservations);

// GET /api/v1/reservations/user/:user_id - Get all reservations for a user
// Place this before the param routes so 'user' isn't interpreted as an :id
router.get('/user/:user_id', getUserReservations);

// GET /api/v1/reservations/:id - Get a reservation by ID
router.get('/:id', getReservationById);

// PUT /api/v1/reservations/:id - Update or cancel a reservation
router.put('/:id', updateReservation);

module.exports = router;

