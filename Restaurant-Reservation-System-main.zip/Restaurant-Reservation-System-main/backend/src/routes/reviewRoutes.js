const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const { authorizedRoles } = require('../middleware/authorizationMiddleware');
const authenticate = require('../middleware/authenticationMiddleware');

// Get reviews (public)
router.get('/', reviewController.listReviews);

// Submit a review
router.post('/', authenticate, reviewController.createReview);

// Edit a review
router.put('/:id', authenticate, reviewController.updateReview);

// Delete a review
router.delete('/:id', authenticate, reviewController.deleteReview);

module.exports = router;
