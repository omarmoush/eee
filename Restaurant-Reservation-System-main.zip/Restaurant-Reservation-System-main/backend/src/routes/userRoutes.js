const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const registerController = require('../controllers/registerController');
const loginController = require('../controllers/loginController');
const authenticate = require('../middleware/authenticationMiddleware');

router.post('/register', registerController.createUser);

router.post('/login', loginController.loginUser);

router.get('/profile/', authenticate, userController.getUserProfile);

router.put('/profile/', authenticate, userController.updateUserProfile);

module.exports = router;