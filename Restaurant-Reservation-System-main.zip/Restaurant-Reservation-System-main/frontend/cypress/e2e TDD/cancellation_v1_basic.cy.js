describe('Cancellation Feature - Iteration 1: Basic Functionality', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Cancel V1',
    email: `cancel_v1_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };

  before(() => {
    // Register
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user).then((res) => {
      const userId = res.body.user.id;
      // Seed a reservation directly via API to ensure we have something to cancel
      cy.request('POST', 'http://localhost:3000/api/v1/reservations', {
        user_id: userId,
        date: '2025-11-11',
        time: '18:00',
        partySize: 2,
        contactPhone: user.phone,
        contactEmail: user.email
      });
    });
  });

  it('should allow user to cancel an existing reservation', () => {
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    
    cy.contains('Reservations').click();

    // Find the reservation and click cancel
    // Assuming there is a cancel button for the reservation
    cy.contains('2025-11-11').parent().find('button').contains('Cancel').click();

    // Assert status change or removal
    // Based on typical implementation, it might change status to 'Cancelled'
    cy.contains('Cancelled').should('be.visible');
  });
});
