describe('Cancellation Feature - Iteration 2: UI Feedback', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Cancel V2',
    email: `cancel_v2_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };

  before(() => {
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user).then((res) => {
      const userId = res.body.user.id;
      cy.request('POST', 'http://localhost:3000/api/v1/reservations', {
        user_id: userId,
        date: '2025-11-12',
        time: '18:00',
        partySize: 4,
        contactPhone: user.phone,
        contactEmail: user.email
      });
    });
  });

  it('should update the UI immediately after cancellation', () => {
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    
    cy.contains('Reservations').click();

    // Verify initial state
    cy.contains('2025-11-12').should('exist');
    cy.contains('Pending').should('exist');

    // Cancel
    cy.contains('2025-11-12').parent().find('button').contains('Cancel').click();

    // Verify immediate UI update without reload
    cy.contains('Cancelled').should('be.visible');
    
    // Verify the Cancel button is now disabled or gone
    cy.contains('2025-11-12').parent().find('button').contains('Cancel').should('not.exist');
  });
});
