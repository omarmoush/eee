describe('Cancellation Feature - Iteration 3: Robustness & Verification', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Cancel V3',
    email: `cancel_v3_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };
  let reservationId;

  before(() => {
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user).then((res) => {
      const userId = res.body.user.id;
      cy.request('POST', 'http://localhost:3000/api/v1/reservations', {
        user_id: userId,
        date: '2025-11-13',
        time: '19:00',
        partySize: 2,
        contactPhone: user.phone,
        contactEmail: user.email
      }).then((r) => {
        reservationId = r.body.data._id;
      });
    });
  });

  it('should verify cancellation on the backend', () => {
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    
    cy.contains('Reservations').click();

    // Intercept the cancel request
    cy.intercept('PUT', `/api/v1/reservations/${reservationId}`).as('cancelRequest');

    // Perform Cancel
    cy.contains('2025-11-13').parent().find('button').contains('Cancel').click();

    // Wait for network request
    cy.wait('@cancelRequest').its('response.statusCode').should('eq', 200);

    // Verify UI
    cy.contains('Cancelled').should('be.visible');

    // Double check via API that it is actually cancelled
    cy.request('GET', `http://localhost:3000/api/v1/reservations/${reservationId}`).then((res) => {
      expect(res.body.data.status).to.equal('Cancelled');
    });
  });
});
