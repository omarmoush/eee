describe('Reservation Feature - Iteration 1: Basic Happy Path', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Reserve V1',
    email: `reserve_v1_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };

  before(() => {
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user);
  });

  it('should successfully create a reservation with valid data', () => {
    // 1. Login
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    cy.url().should('include', '/home');

    // 2. Navigate to Reservations
    cy.contains('Reservations').click();
    cy.url().should('include', '/reservations');

    // 3. Fill Form
    cy.get('input[name="date"]').type('2025-12-25');
    cy.get('input[name="time"]').type('19:00');
    cy.get('input[name="partySize"]').clear().type('4');
    cy.get('input[name="contactPhone"]').type(user.phone);
    cy.get('input[name="contactEmail"]').type(user.email);

    // 4. Submit
    cy.contains('button', 'Submit reservation').click();

    // 5. Assert Success
    cy.contains('Reservation created successfully').should('be.visible');
  });
});
