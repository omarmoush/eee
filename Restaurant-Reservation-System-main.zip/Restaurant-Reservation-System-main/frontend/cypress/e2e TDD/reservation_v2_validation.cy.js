describe('Reservation Feature - Iteration 2: Validation & Constraints', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Reserve V2',
    email: `reserve_v2_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };

  before(() => {
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user);
  });

  beforeEach(() => {
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    cy.contains('Reservations').click();
  });

  it('should show error when required fields are missing', () => {
    // Clear default values if any
    cy.get('input[name="contactPhone"]').clear();
    cy.get('input[name="contactEmail"]').clear();
    
    cy.contains('button', 'Submit reservation').click();
    
    // Assuming HTML5 validation or UI error message
    // If the browser handles it, we might need to check :invalid pseudo-class
    // Or if the app shows an alert/toast
    cy.get('input[name="contactPhone"]:invalid').should('exist');
  });

  it('should not allow party size less than 1', () => {
    cy.get('input[name="partySize"]').clear().type('0');
    cy.contains('button', 'Submit reservation').click();
    // Check for validation error
    cy.get('input[name="partySize"]:invalid').should('exist');
  });
});
