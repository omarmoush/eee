describe('Reservation Feature - Iteration 3: Full Integration & State', () => {
  const timestamp = Date.now();
  const user = {
    name: 'Reserve V3',
    email: `reserve_v3_${timestamp}@test.com`,
    password: 'password123',
    phone: '1234567890'
  };

  before(() => {
    cy.request('POST', 'http://localhost:3000/api/v1/users/register', user);
  });

  it('should persist reservation and show in "My Reservations" list', () => {
    // Login
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]').type(user.email);
    cy.get('[data-cy="login-password"]').type(user.password);
    cy.get('[data-cy="login-submit"]').click();
    
    cy.contains('Reservations').click();

    // Create Reservation
    const date = '2025-12-31';
    const time = '20:00';
    
    cy.get('input[name="date"]').type(date);
    cy.get('input[name="time"]').type(time);
    cy.get('input[name="partySize"]').clear().type('2');
    cy.get('input[name="contactPhone"]').type(user.phone);
    cy.get('input[name="contactEmail"]').type(user.email);
    cy.get('textarea[name="specialRequests"]').type('Window seat please');

    cy.contains('button', 'Submit reservation').click();
    cy.contains('Reservation created successfully').should('be.visible');

    // Verify it appears in the list below
    // Date format might vary, so we check for time or other unique details
    cy.contains(time).should('be.visible');
    cy.contains('Window seat please').should('be.visible');
    cy.contains('pending').should('be.visible'); // Default status

    // Reload page to verify persistence
    cy.reload();
    cy.contains('Window seat please').should('be.visible');
  });
});
