describe('E2E: Login → Add to Cart → Checkout', () => {
  const existingUser = { 
    email: 'pleasework@gmail.com',
    password: 'HelloWorld99'
  };

  it('completes full checkout flow from login to order confirmation', () => {
    // Step 1: Login
    cy.visit('http://localhost:3000/');
    cy.get('[data-cy="login-email"]', { timeout: 10000 }).should('be.visible').type(existingUser.email);
    cy.get('[data-cy="login-password"]').type(existingUser.password);
    cy.intercept('POST', '/api/v1/users/login').as('loginUser');
    cy.get('[data-cy="login-submit"]').click();
    cy.wait('@loginUser');
    cy.url().should('include', '/home');

    // Step 2: Navigate to cart
    cy.get('[data-cy="navbar-cart"]', { timeout: 10000 }).should('be.visible').click();
    cy.url().should('include', '/cart');

    // Step 3: If cart is empty, go to menu and add item
    cy.get('body').then(($body) => {
      if ($body.find('[data-cy="browse-menu"]').length) {
        cy.get('[data-cy="browse-menu"]').click();
        cy.url().should('include', '/menu');
        
        // Add first available menu item
        cy.get('[data-cy="menu-item"]', { timeout: 10000 }).first().within(() => {
          cy.get('[data-cy="add-to-cart"]').click();
        });
        
        // Should redirect back to cart
        cy.url().should('include', '/cart');
      }
    });

    // Step 4: Verify cart has items
    cy.get('[data-cy="cart-item"]').should('have.length.greaterThan', 0);

    // Step 5: Proceed to checkout
    cy.get('[data-cy="checkout-btn"]').click();
    cy.url().should('include', '/checkout');

    // Step 6: Fill checkout form
    const pickupTime = new Date(Date.now() + 3600 * 1000)
      .toISOString()
      .slice(0, 16);

    cy.get('[data-cy="pickup-time"]').select(1); // Select first available time slot
    cy.get('[data-cy="contact-phone"]').clear().type('1234567890');

    // Step 7: Place order
    cy.intercept('POST', '/api/v1/orders').as('placeOrder');
    cy.get('[data-cy="place-order"]').click();
    cy.wait('@placeOrder');
    
    // Step 8: Verify success
    cy.get('[data-cy="order-success"]', { timeout: 10000 }).should('exist');
  });
});