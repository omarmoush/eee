// Preserve localStorage between tests (useful for multi-test suites)
let LOCAL_STORAGE_MEMORY = {};

Cypress.Commands.add('saveLocalStorage', () => {
  cy.window().then((win) => {
    Object.keys(win.localStorage).forEach(key => {
      LOCAL_STORAGE_MEMORY[key] = win.localStorage.getItem(key);
    });
  });
});

Cypress.Commands.add('restoreLocalStorage', () => {
  cy.window().then((win) => {
    Object.keys(LOCAL_STORAGE_MEMORY).forEach(key => {
      win.localStorage.setItem(key, LOCAL_STORAGE_MEMORY[key]);
    });
  });
});

// Automatically preserve localStorage between tests
afterEach(() => {
  cy.saveLocalStorage();
});

beforeEach(() => {
  cy.restoreLocalStorage();
});
