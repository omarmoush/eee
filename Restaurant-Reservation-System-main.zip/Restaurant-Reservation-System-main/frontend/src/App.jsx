import React from 'react'
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom'
import './App.css'
import Login from './pages/Login'
import Register from './pages/Register'
import Home from './pages/Home'
import Reviews from './pages/Reviews'
import MenuDisplay from './pages/MenuDisplay'
import MenuAdmin from './pages/MenuAdmin'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import OrderConfirmation from './pages/OrderConfirmation'
import AdminOrders from './pages/AdminOrders'
import MyOrders from './pages/MyOrders'
import Reservations from './pages/Reservations'
import Notifications from './pages/Notifications'
import Analytics from './pages/Analytics'
import ProtectedRoute from './components/ProtectedRoute'

// --- Navigation Component ---
function Navigation() {
  const navigate = useNavigate()
  const location = useLocation()
  const token = localStorage.getItem('token')

  // Default to "User" if token is missing or invalid
  let userRole = 'User'
  if (token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]))
      if (payload && payload.role) {
        userRole = payload.role
      }
    } catch (e) {
      console.error('Error parsing token:', e)
    }
  }

  // Check if user is Admin (case-insensitive for safety)
  const isAdmin = userRole && userRole.toLowerCase() === 'admin'

  // Handlers
  const handleLogout = () => {
    localStorage.removeItem('token')
    navigate('/')
  }
  const handleReserve = () => navigate('/reservations')
  const handleBack = () => navigate('/home')
  const handleManageMenu = () => navigate('/admin/menu')
  const handleNotifications = () => navigate('/notifications')
  const handleAnalytics = () => navigate('/analytics')

  // Render navbar
  return (
    <nav className="navbar">
      <div className="nav-brand">
        <div className="logo-circle">LS</div>
        <div className="brand-text">
          <span className="brand-title">Les Cooked</span>
          <span className="brand-sub">Diner</span>
        </div>
      </div>

      <div className="nav-actions">
        {location.pathname !== '/home' && (
          <button onClick={handleBack} className="btn-back">Back</button>
        )}

        {/* Admin menu */}
        {isAdmin && (
          <>
            <button onClick={handleManageMenu} className="btn btn-admin-menu">Manage Menu</button>
            <button onClick={() => navigate('/admin/orders')} className="btn btn-admin-menu">Manage Orders</button>
            <button onClick={handleAnalytics} className="btn-back">Analytics</button>
          </>
        )}

        {/* Regular user menu */}
        {!isAdmin && token && (
          <>
            <button 
              data-cy="navbar-cart" 
              onClick={() => navigate('/cart')} 
              className="btn btn-cart"
            >
              Cart
            </button>
            <button 
              data-cy="navbar-my-orders"
              onClick={() => navigate('/my-orders')} 
              className="btn btn-cart"
            >
              My Orders
            </button>
            <button 
              data-cy="navbar-reserve"
              onClick={handleReserve} 
              className="btn btn-reserve"
            >
              Reserve
            </button>
          </>
        )}

        {/* Menu items visible for all logged-in users */}
        {token && (
          <>
            <button onClick={() => navigate('/menu')} className="btn btn-menu">Menu</button>
            <button onClick={handleNotifications} className="btn-back">Notifications</button>
            <button onClick={handleLogout} className="btn btn-primary">Logout</button>
          </>
        )}
      </div>
    </nav>
  )
}

// --- App Component ---
function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
            <Route path="/reservations" element={<ProtectedRoute><Reservations /></ProtectedRoute>} />
            <Route path="/reviews" element={<ProtectedRoute><Reviews /></ProtectedRoute>} />
            <Route path="/menu" element={<ProtectedRoute><MenuDisplay /></ProtectedRoute>} />
            <Route path="/admin/menu" element={<ProtectedRoute><MenuAdmin /></ProtectedRoute>} />
            <Route path="/analytics" element={<ProtectedRoute><Analytics /></ProtectedRoute>} />
            <Route path="/cart" element={<ProtectedRoute><Cart /></ProtectedRoute>} />
            <Route path="/checkout" element={<ProtectedRoute><Checkout /></ProtectedRoute>} />
            <Route path="/order-confirmation/:orderId" element={<ProtectedRoute><OrderConfirmation /></ProtectedRoute>} />
            <Route path="/admin/orders" element={<ProtectedRoute><AdminOrders /></ProtectedRoute>} />
            <Route path="/my-orders" element={<ProtectedRoute><MyOrders /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
          </Routes>
        </main>

        <footer className="footer">
          <p>&copy; 2025 Les Cooked. All rights reserved.</p>
        </footer>
      </div>
    </Router>
  )
}

export default App
