import axios from 'axios'

const reviewsAPI = axios.create({
  baseURL: '/api/v1/reviews',
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor to add auth token
reviewsAPI.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
reviewsAPI.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/'
    }
    return Promise.reject(error)
  }
)

// Reviews API methods
export const getReviews = () => reviewsAPI.get('/')
export const createReview = (data) => reviewsAPI.post('/', data)
export const updateReview = (id, data) => reviewsAPI.put(`/${id}`, data)
export const deleteReview = (id) => reviewsAPI.delete(`/${id}`)

// Menu API
const menuAPI = axios.create({
  baseURL: '/api/v1/menu',
  headers: {
    'Content-Type': 'application/json'
  }
})

// Request interceptor to add auth token
menuAPI.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
menuAPI.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/'
    }
    return Promise.reject(error)
  }
)

// Menu API methods
export const menuAPIExports = {
  getAllMenuItems: () => menuAPI.get('/').then(res => res.data),
  createMenuItem: (data) => menuAPI.post('/', data).then(res => res.data),
  updateMenuItem: (id, data) => menuAPI.put(`/${id}`, data).then(res => res.data),
  deleteMenuItem: (id) => menuAPI.delete(`/${id}`).then(res => res.data)
}

export { menuAPIExports as menuAPI }

export default reviewsAPI
