import axios from 'axios'

const dashboardAPI = axios.create({
  baseURL: '/api/v1/dashboard',
  headers: {
    'Content-Type': 'application/json'
  }
})

// Attach auth token if present
dashboardAPI.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Handle unauthorized globally
dashboardAPI.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/'
    }
    return Promise.reject(error)
  }
)

export const getNotifications = (userId) => dashboardAPI.get(`/${userId}`)
export const createNotification = (data) => dashboardAPI.post('/', data)
export const markAsRead = (id) => dashboardAPI.put(`/${id}`)
export const getAnalytics = () => dashboardAPI.get('/analytics')

export default dashboardAPI
