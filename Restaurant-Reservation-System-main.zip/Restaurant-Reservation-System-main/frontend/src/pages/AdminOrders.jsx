import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    fetchOrders();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [filterStatus, filterType, orders]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:3000/api/v1/orders/all', {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (response.data.success || response.data) {
        const orderData = response.data.data || response.data;
        setOrders(Array.isArray(orderData) ? orderData : []);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
      setError('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...orders];

    if (filterStatus !== 'all') {
      filtered = filtered.filter(order => order.status === filterStatus);
    }

    if (filterType !== 'all') {
      filtered = filtered.filter(order => order.order_type === filterType);
    }

    setFilteredOrders(filtered);
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:3000/api/v1/orders/${orderId}`,
        { status: newStatus },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      // Update local state
      setOrders(prev => prev.map(order => 
        order._id === orderId ? { ...order, status: newStatus } : order
      ));
    } catch (err) {
      console.error('Error updating order status:', err);
      alert('Failed to update order status');
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: '#FFA500',
      confirmed: '#4CAF50',
      preparing: '#2196F3',
      ready: '#9C27B0',
      completed: '#4CAF50',
      cancelled: '#F44336'
    };
    return colors[status] || '#757575';
  };

  if (loading) {
    return (
      <div className="admin-orders-container">
        <div className="loading">Loading orders...</div>
      </div>
    );
  }

  return (
    <div className="admin-orders-container">
      <div className="admin-orders-header">
        <h1>Order Management</h1>
        <button className="btn-refresh" onClick={fetchOrders}>
          Refresh
        </button>
      </div>

      {error && (
        <div className="error-banner">
          <p>{error}</p>
        </div>
      )}

      {/* Filters */}
      <div className="filters-container">
        <div className="filter-group">
          <label>Status:</label>
          <select 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="preparing">Preparing</option>
            <option value="ready">Ready</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <div className="filter-group">
          <label>Order Type:</label>
          <select 
            value={filterType} 
            onChange={(e) => setFilterType(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Types</option>
            <option value="pickup">Pickup</option>
            <option value="dineIn">Dine In</option>
          </select>
        </div>

        <div className="filter-stats">
          <span>Showing {filteredOrders.length} of {orders.length} orders</span>
        </div>
      </div>

      {/* Orders List */}
      <div className="orders-grid">
        {filteredOrders.length === 0 ? (
          <div className="no-orders">
            <p>No orders found</p>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div key={order._id} className="order-card">
              <div className="order-card-header">
                <div>
                  <h3>Order #{order._id?.slice(-8)}</h3>
                  <p className="order-date">{formatDate(order.createdAt)}</p>
                </div>
                <span 
                  className="order-type-badge"
                  style={{ 
                    backgroundColor: order.order_type === 'pickup' ? '#FF9800' : '#3F51B5',
                    color: 'white',
                    padding: '0.25rem 0.75rem',
                    borderRadius: '12px',
                    fontSize: '0.85rem'
                  }}
                >
                  {order.order_type === 'pickup' ? 'Pickup' : 'Dine In'}
                </span>
              </div>

              <div className="order-card-body">
                {/* Customer Info */}
                <div className="order-info-section">
                  <p className="info-label">Customer:</p>
                  <p className="info-value">
                    {order.user_id?.firstName || order.user_id?.name || 'Unknown'}
                  </p>
                </div>

                {/* Order Type Specific Info */}
                {order.order_type === 'pickup' && order.pickup_time && (
                  <div className="order-info-section">
                    <p className="info-label">Pickup Time:</p>
                    <p className="info-value">{formatDate(order.pickup_time)}</p>
                  </div>
                )}

                {order.order_type === 'pickup' && order.contact_phone && (
                  <div className="order-info-section">
                    <p className="info-label">Contact:</p>
                    <p className="info-value">{order.contact_phone}</p>
                  </div>
                )}

                {order.order_type === 'dineIn' && order.reservation_id && (
                  <div className="order-info-section">
                    <p className="info-label">Reservation:</p>
                    <p className="info-value">{order.reservation_id}</p>
                  </div>
                )}

                {order.order_type === 'dineIn' && order.table_number && (
                  <div className="order-info-section">
                    <p className="info-label">Table:</p>
                    <p className="info-value">{order.table_number}</p>
                  </div>
                )}

                {/* Items */}
                <div className="order-items-summary">
                  <p className="info-label">Items:</p>
                  {order.menu_items?.slice(0, 3).map((item, index) => (
                    <p key={index} className="item-summary">
                      • {item.menu_item?.name || 'Item'} x{item.quantity}
                    </p>
                  ))}
                  {order.menu_items?.length > 3 && (
                    <p className="more-items">+{order.menu_items.length - 3} more...</p>
                  )}
                </div>

                {/* Payment */}
                <div className="order-info-section">
                  <p className="info-label">Payment:</p>
                  <p className="info-value">
                    {order.payment_method === 'cash' ? 'Cash' : 'Card'}
                  </p>
                </div>

                {/* Total */}
                <div className="order-total-section">
                  <span className="total-label">Total:</span>
                  <span className="total-amount">{formatPrice(
                    order.menu_items?.reduce((sum, item) => 
                      sum + ((item.menu_item?.price || item.price) * item.quantity), 0
                    ) || order.total_price
                  )}</span>
                </div>

                {/* Status Update */}
                <div className="status-update-section">
                  <label htmlFor={`status-${order._id}`}>Update Status:</label>
                  <select
                    id={`status-${order._id}`}
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order._id, e.target.value)}
                    className="status-select"
                    style={{ 
                      borderColor: getStatusColor(order.status),
                      color: getStatusColor(order.status)
                    }}
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="preparing">Preparing</option>
                    <option value="ready">Ready</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                {order.special_instructions && (
                  <div className="special-instructions">
                    <p className="info-label">Special Instructions:</p>
                    <p className="instructions-text">{order.special_instructions}</p>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminOrders;
