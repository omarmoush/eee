import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getAnalytics } from '../api/dashboard'

function Analytics() {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const token = localStorage.getItem('token')
  let payload = null
  try {
    payload = token ? JSON.parse(atob(token.split('.')[1] || '')) : null
  } catch (err) {
    payload = null
  }
  const isAdmin = payload?.role === 'Admin'

  useEffect(() => {
    if (!isAdmin) return

    const fetchAnalytics = async () => {
      try {
        const res = await getAnalytics()
        setData(res.data.analytics || res.data || null)
        setError('')
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load analytics')
      }
    }

    fetchAnalytics()
  }, [isAdmin])

  if (!isAdmin) {
    return (
      <div className="container">
        <p>You need admin access to view analytics.</p>
        <button onClick={() => navigate('/home')} className="btn-back" style={{ marginTop: '0.8rem' }}>
          Back to Home
        </button>
      </div>
    )
  }

  if (!data) {
    return <div className="container">Loading analytics...</div>
  }

  const cards = [
    { label: 'Total Users', value: data.users?.total },
    { label: 'Customers', value: data.users?.customers },
    { label: 'Admins', value: data.users?.admins },
    { label: 'Avg Rating', value: data.reviews?.averageRating },
    { label: 'Total Reviews', value: data.reviews?.total },
    { label: 'Total Reservations', value: data.reservations?.total },
    { label: 'Total Orders', value: data.orders?.total },
    { label: 'Revenue', value: data.orders?.totalRevenue }
  ]

  return (
    <div className="container">
      <h1 className="page-title">Analytics</h1>
      {error && <div style={{ color: 'red', marginBottom: '1rem' }}>{error}</div>}

      <div className="feature-grid">
        {cards.map((card) => (
          <div key={card.label} className="feature-card" style={{ minHeight: 160 }}>
            <div className="feature-overlay" style={{ background: 'rgba(0, 0, 0, 0.65)' }}>
              <h3 className="feature-title" style={{ marginBottom: '0.3rem' }}>{card.label}</h3>
              <p className="feature-desc" style={{ fontSize: '1.4rem', fontWeight: 700 }}>
                {card.value !== undefined && card.value !== null ? card.value : '—'}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Analytics
