import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  const [cartItems, setCartItems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartItems(cart);
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const updateQuantity = (itemId, newQuantity) => {
    if (newQuantity < 1) return;
    const updatedCart = cartItems.map(item =>
      item._id === itemId ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const removeItem = (itemId) => {
    const updatedCart = cartItems.filter(item => item._id !== itemId);
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const clearCart = () => {
    setCartItems([]);
    localStorage.removeItem('cart');
  };

  const calculateTotal = () => cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (cartItems.length === 0) {
    return (
      <div className="cart-container">
        <div className="empty-cart">
          <h1>Your Cart is Empty</h1>
          <p>Add some delicious items to get started!</p>
          <button data-cy="browse-menu" className="btn-browse" onClick={() => navigate('/menu')}>
            Browse Menu
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-container">
      <div className="cart-header">
        <h1>Shopping Cart</h1>
        <button data-cy="clear-cart" className="btn-clear-cart" onClick={clearCart}>
          Clear Cart
        </button>
      </div>

      <div className="cart-content">
        <div className="cart-items">
          {cartItems.map((item) => (
            <div key={item._id} className="cart-item" data-cy="cart-item">
              {item.image && (
                <div className="cart-item-image">
                  <img src={item.image} alt={item.name} />
                </div>
              )}
              
              <div className="cart-item-details">
                <h3>{item.name}</h3>
                <p className="cart-item-description">{item.description}</p>
                <p className="cart-item-price">{formatPrice(item.price)} each</p>
              </div>

              <div className="cart-item-controls">
                <div className="quantity-controls">
                  <button
                    data-cy="decrease-qty"
                    className="btn-quantity"
                    onClick={() => updateQuantity(item._id, item.quantity - 1)}
                    aria-label="Decrease quantity"
                  >
                    −
                  </button>
                  <span data-cy="quantity" className="quantity-display">{item.quantity}</span>
                  <button
                    data-cy="increase-qty"
                    className="btn-quantity"
                    onClick={() => updateQuantity(item._id, item.quantity + 1)}
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
                
                <p className="cart-item-total">
                  {formatPrice(item.price * item.quantity)}
                </p>
                
                <button
                  data-cy="remove-item"
                  className="btn-remove"
                  onClick={() => removeItem(item._id)}
                  aria-label="Remove item"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="cart-summary">
          <h2>Order Summary</h2>
          
          <div data-cy="cart-total" className="summary-row summary-total">
            <span>Total:</span>
            <span>{formatPrice(calculateTotal())}</span>
          </div>          
          <button data-cy="checkout-btn" className="btn-checkout" onClick={() => navigate('/checkout')}>
            Proceed to Checkout
          </button>
          
          <button data-cy="continue-shopping" className="btn-continue" onClick={() => navigate('/menu')}>
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
