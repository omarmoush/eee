import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Checkout = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [timeSlots, setTimeSlots] = useState([]);
  
  const [formData, setFormData] = useState({
    orderType: 'pickup',
    paymentMethod: 'cash',
    pickupTime: '',
    contactPhone: '',
    specialInstructions: '',
    reservationId: '',
    tableNumber: '',
  });

  // Helper function to get user ID
  const getUserId = () => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    let userId = user.id || user._id;

    // If no user ID in localStorage, try to decode from token
    if (!userId) {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const payload = JSON.parse(atob(token.split('.')[1]));
          userId = payload.userId;
        } catch (e) {
          console.error('Failed to decode token:', e);
        }
      }
    }

    return userId;
  };

  useEffect(() => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    if (cart.length === 0) {
      navigate('/cart');
      return;
    }
    setCartItems(cart);

    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (user.phone) {
      setFormData(prev => ({ ...prev, contactPhone: user.phone }));
    }

    generateTimeSlots();
    fetchActiveOrders();
  }, [navigate]);

  const generateTimeSlots = () => {
    const slots = [];
    const now = new Date();
    const startHour = 10;
    const endHour = 22;
    const currentHour = now.getHours();
    
    // Determine which day(s) to show slots for
    // If it's past closing time (10 PM), show slots for tomorrow only
    // Otherwise, show slots for today and tomorrow if needed
    const showToday = currentHour < endHour;
    const daysToShow = showToday ? [0, 1] : [1]; // 0 = today, 1 = tomorrow
    
    for (let dayOffset of daysToShow) {
      const date = new Date(now);
      date.setDate(date.getDate() + dayOffset);
      
      for (let hour = startHour; hour < endHour; hour++) {
        for (let minute of [0, 30]) {
          const slotTime = new Date(date);
          slotTime.setHours(hour, minute, 0, 0);
          
          // Only add slots that are in the future
          if (slotTime > now) {
            slots.push({
              value: slotTime.toISOString(),
              label: slotTime.toLocaleString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              }),
              time: slotTime,
              available: true
            });
          }
        }
      }
    }
    
    setTimeSlots(slots);
  };

  const fetchActiveOrders = async () => {
    try {
      const token = localStorage.getItem('token');
      const userId = getUserId();
      
      if (!userId) {
        console.error('User ID not found');
        return;
      }
      
      const response = await axios.get(
        `http://localhost:3000/api/v1/orders/user/${userId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.success || response.data) {
        const orders = response.data.data || response.data;
        checkTimeSlotAvailability(orders);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const checkTimeSlotAvailability = (orders) => {
    const activeOrders = orders.filter(order => 
      ['pending', 'confirmed', 'preparing'].includes(order.status)
    );

    setTimeSlots(prev => prev.map(slot => {
      const slotTime = new Date(slot.value);
      const ordersInSlot = activeOrders.filter(order => {
        if (!order.pickup_time) return false;
        const orderTime = new Date(order.pickup_time);
        const timeDiff = Math.abs(slotTime - orderTime);
        return timeDiff < 30 * 60 * 1000;
      });

      return {
        ...slot,
        available: ordersInSlot.length < 2
      };
    }));
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const calculateTotal = () => {
    return cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    if (formData.orderType === 'pickup') {
      if (!formData.pickupTime) {
        setError('Please select a pickup time');
        return false;
      }
      if (!formData.contactPhone) {
        setError('Please provide a contact phone number');
        return false;
      }
    } else if (formData.orderType === 'dineIn') {
      if (!formData.reservationId) {
        setError('Please provide your reservation ID');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('token');
      const userId = getUserId();

      if (!userId) {
        setError('User ID not found. Please log in again.');
        setLoading(false);
        return;
      }

      // Prepare order data
      const orderData = {
        user_id: userId,
        menu_items: cartItems.map(item => ({
          menu_item_id: item._id,
          quantity: item.quantity
        })),
        order_type: formData.orderType,
        payment_method: formData.paymentMethod,
        status: 'pending',
        total_price: calculateTotal(),
        special_instructions: formData.specialInstructions,
      };

      // Add type-specific fields
      if (formData.orderType === 'pickup') {
        orderData.pickup_time = formData.pickupTime;
        orderData.contact_phone = formData.contactPhone;
      } else {
        orderData.reservation_id = formData.reservationId;
        orderData.table_number = formData.tableNumber;
      }

      // Submit order
      const response = await axios.post(
        'http://localhost:3000/api/v1/orders',
        orderData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        localStorage.removeItem('cart');
        setSuccess(true);
        setCartItems([]);
        
        setTimeout(() => {
          navigate('/my-orders');
        }, 2000);
      }
    } catch (err) {
      console.error('Error placing order:', err);
      setError(err.response?.data?.message || 'Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="checkout-container">
        <div className="success-message" data-cy="order-success">
          <div className="success-icon">✓</div>
          <h1>Order Placed Successfully!</h1>
          <p>Redirecting to your orders...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="checkout-container">
      <h1>Checkout</h1>

      <div className="checkout-content">
        <form className="checkout-form" onSubmit={handleSubmit}>
          {error && (
            <div className="error-banner">
              <p>{error}</p>
            </div>
          )}

          {/* Order Type Selection */}
          <div className="form-section">
            <h2>Order Type</h2>
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  name="orderType"
                  value="pickup"
                  checked={formData.orderType === 'pickup'}
                  onChange={handleInputChange}
                />
                <span className="radio-content">
                  <span className="radio-title">Pickup</span>
                  <span className="radio-description">Order ready for pickup</span>
                </span>
              </label>
              
              <label className="radio-label">
                <input
                  type="radio"
                  name="orderType"
                  value="dineIn"
                  checked={formData.orderType === 'dineIn'}
                  onChange={handleInputChange}
                />
                <span className="radio-content">
                  <span className="radio-title">Dine In</span>
                  <span className="radio-description">Associated with reservation</span>
                </span>
              </label>
            </div>
          </div>

          {/* Conditional Fields Based on Order Type */}
          {formData.orderType === 'pickup' && (
            <div className="form-section">
              <h2>Pickup Details</h2>
              
              <div className="form-group">
                <label htmlFor="pickupTime">
                  Pickup Time <span className="required">*</span>
                </label>
                <select
                  id="pickupTime"
                  name="pickupTime"
                  value={formData.pickupTime}
                  onChange={handleInputChange}
                  required
                  className="form-select"
                  data-cy="pickup-time"
                >
                  <option value="">Select a time slot</option>
                  {timeSlots.map((slot) => (
                    <option 
                      key={slot.value} 
                      value={slot.value}
                      disabled={!slot.available}
                    >
                      {slot.label} {!slot.available ? '(Unavailable)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="contactPhone">
                  Contact Phone <span className="required">*</span>
                </label>
                <input
                  type="tel"
                  id="contactPhone"
                  name="contactPhone"
                  value={formData.contactPhone}
                  onChange={handleInputChange}
                  placeholder="+1 (555) 123-4567"
                  required
                  data-cy="contact-phone"
                />
              </div>
            </div>
          )}

          {formData.orderType === 'dineIn' && (
            <div className="form-section">
              <h2>Dine-In Details</h2>
              
              <div className="form-group">
                <label htmlFor="reservationId">
                  Reservation ID <span className="required">*</span>
                </label>
                <input
                  type="text"
                  id="reservationId"
                  name="reservationId"
                  value={formData.reservationId}
                  onChange={handleInputChange}
                  placeholder="e.g., RES-12345"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="tableNumber">Table Number (Optional)</label>
                <input
                  type="text"
                  id="tableNumber"
                  name="tableNumber"
                  value={formData.tableNumber}
                  onChange={handleInputChange}
                  placeholder="e.g., Table 5"
                />
              </div>
            </div>
          )}

          {/* Payment Method */}
          <div className="form-section">
            <h2>Payment Method</h2>
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  name="paymentMethod"
                  value="cash"
                  checked={formData.paymentMethod === 'cash'}
                  onChange={handleInputChange}
                />
                <span className="radio-content">
                  <span className="radio-title">Cash</span>
                  <span className="radio-description">Pay on {formData.orderType === 'pickup' ? 'pickup' : 'arrival'}</span>
                </span>
              </label>
            </div>
          </div>

          {/* Special Instructions */}
          <div className="form-section">
            <h2>Special Instructions (Optional)</h2>
            <div className="form-group">
              <textarea
                name="specialInstructions"
                value={formData.specialInstructions}
                onChange={handleInputChange}
                rows="3"
                placeholder="Any special requests or dietary requirements..."
              />
            </div>
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn-cancel" 
              onClick={() => navigate('/cart')}
              disabled={loading}
            >
              Back to Cart
            </button>
            <button 
              type="submit" 
              className="btn-submit"
              disabled={loading}
              data-cy="place-order"
            >
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
          </div>
        </form>

        {/* Order Summary */}
        <div className="checkout-summary">
          <h2>Order Summary</h2>
          
          <div className="summary-items">
            {cartItems.map((item) => (
              <div key={item._id} className="summary-item">
                <span className="summary-item-name">
                  {item.name} x{item.quantity}
                </span>
                <span className="summary-item-price">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          <div className="summary-divider"></div>
          
          <div className="summary-row summary-total">
            <span>Total:</span>
            <span>{formatPrice(calculateTotal())}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
