import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

const featureCards = [
  {
    title: 'Comfort Plates',
    desc: 'Campus-born favorites, crisp sides, and slow-cooked mains crafted by student chefs.',
    img: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=80',
    cta: 'View Menus',
    href: '/menu'
  },
  {
    title: 'Open Kitchen',
    desc: 'Watch the line work while your plate is built fresh from our uni kitchen.',
    img: 'https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?auto=format&fit=crop&w=1400&q=80',
    cta: 'See Dishes',
    href: '/menu'
  },
  {
    title: 'Guest Reviews',
    desc: 'Hear from diners who shared their night with us on campus.',
    img: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=1400&q=80',
    cta: 'See Reviews',
    href: '/reviews'
  }
]

function Home() {
  const navigate = useNavigate()

  return (
    <div className="container">
      <section className="dining-hero">
        <div className="dining-hero__bg"></div>
        <div className="dining-hero__overlay">
          <h1 className="dining-hero__title">Les Cooked</h1>
          <p className="dining-hero__subtitle">Student-crafted diner plates from the heart of campus.</p>
        </div>
      </section>

      <div className="feature-grid">
        <motion.div
          className="reservation-button-card"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.04, duration: 0.35 }}
          whileHover={{ y: -4 }}
          onClick={() => navigate('/reservations')}
          role="button"
          tabIndex={0}
        >
          <div
            className="reservation-button-bg"
            style={{ backgroundImage: `url('/assets/reservation.png')` }}
          />
          <div className="reservation-button-overlay">
            <div>
              <div className="tag tag-reservation">Reservation</div>
              <h3 className="feature-title" style={{ marginTop: '0.6rem', color: '#fffdf8' }}>Your Table Awaits</h3>
              <p className="feature-desc" style={{ color: '#fffdf8', marginTop: '0.4rem' }}>Choose your time. We’ll handle the rest.</p>
              <div className="feature-actions" style={{ marginTop: '0.8rem' }}>
                <button className="btn btn-reserve">Book a Table</button>
              </div>
            </div>
          </div>
        </motion.div>

        {featureCards.map((card, idx) => (
          <motion.div
            key={card.title}
            className="feature-card"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 * idx, duration: 0.35 }}
            whileHover={{ y: -4 }}
          >
            <div className="feature-bg" style={{ backgroundImage: `url(${card.img})` }}></div>
            <motion.div
              className="feature-overlay"
              initial={{ opacity: 0, y: 40 }}
              whileHover={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              <motion.div
                initial={{ opacity: 0, y: 25 }}
                whileHover={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.24, ease: 'easeOut' }}
              >
                <div className="tag">Signature</div>
                <h3 className="feature-title">{card.title}</h3>
                <p className="feature-desc">{card.desc}</p>
              </motion.div>
              <div className="feature-actions">
                <button onClick={() => navigate(card.href)}>{card.cta}</button>
              </div>
            </motion.div>
          </motion.div>
        ))}
      </div>

      <section className="about-section">
        <div className="about-inner container">
          <div className="about-title">Contact & Location</div>
          <div className="about-grid">
            <div className="about-card">
              <div className="about-heading">Les Cooked Diner</div>
              <div className="about-meta">Administrative Capital, Regional Ring Rd</div>
              <div className="about-meta">Cairo Governorate Desert, Cairo Governorate 4824208, Egypt</div>
              <div className="about-meta">Built by the campus kitchen crew.</div>
              <a className="about-link" href="mailto:omar.hany@giu-uni.de">Email: omar.hany@giu-uni.de</a>
            </div>

            <div className="about-card">
              <div className="about-heading">Hours</div>
              <div className="about-meta">Daily — 12:00 PM to 11:00 PM</div>
              <div className="about-meta">Student pop-ups and specials weekly.</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
