import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Login() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await axios.post('/api/v1/users/login', formData);
      localStorage.setItem('token', response.data.token);
      navigate('/home');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check your credentials ˙◠˙');
    } finally { setLoading(false); }
  };

  return (
    <div className="container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <h1 className="page-title" style={{ marginBottom: '2rem', textAlign: 'center', color: '#c8570bff' }}>Restaurant Login</h1>
        <form data-cy="login-form" onSubmit={handleSubmit}>
          {error && <div data-cy="login-error" style={{ color: '#ff4444', backgroundColor: '#ffeeee', padding: '1rem', borderRadius: '4px', marginBottom: '1rem', textAlign: 'center' }}>{error}</div>}
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              data-cy="login-email"
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Enter your email"
              disabled={loading}
              style={{ width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0' }}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              data-cy="login-password"
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Enter your password"
              disabled={loading}
              style={{ width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0' }}
            />
          </div>

          <button data-cy="login-submit" type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1rem' }} disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>

          <div style={{ textAlign: 'center', marginTop: '1rem' }}>
            <p>
              <strong>Don't have an account?</strong>{' '}
              <Link to="/register" data-cy="register-link" style={{ textDecoration: 'none', color: '#9a0439ff', transition: 'all 0.3s ease', textShadow: '0 0 2px #9a0439ff' }}>
                Register right here! ^ᴗ^
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;
