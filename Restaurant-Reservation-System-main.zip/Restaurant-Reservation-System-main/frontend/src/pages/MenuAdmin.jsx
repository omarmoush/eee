import React, { useState, useEffect } from 'react';
import { menuAPI } from '../api/api';
import MenuItemCard from './MenuItemCard';
import MenuItemForm from './MenuItemForm';

const MenuAdmin = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  useEffect(() => {
    fetchMenuItems();
  }, []);

  const fetchMenuItems = async () => {
    try {
      setLoading(true);
      setError(null);
      const items = await menuAPI.getAllMenuItems();
      setMenuItems(items);
    } catch (err) {
      const errorMessage = err.response?.data?.error || 
                          err.message || 
                          'Failed to load menu items. Please make sure the backend server is running on port 3000.';
      setError(errorMessage);
      console.error('Error fetching menu items:', err);
      console.error('Error details:', {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
        url: err.config?.url
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = () => {
    setEditingItem(null);
    setShowForm(true);
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setShowForm(true);
  };

  const handleFormSubmit = async (formData) => {
    try {
      if (editingItem) {
        await menuAPI.updateMenuItem(editingItem._id, formData);
      } else {
        await menuAPI.createMenuItem(formData);
      }
      setShowForm(false);
      setEditingItem(null);
      fetchMenuItems();
    } catch (err) {
      alert(`Failed to ${editingItem ? 'update' : 'create'} menu item: ${err.response?.data?.error || err.message}`);
      console.error('Error saving menu item:', err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await menuAPI.deleteMenuItem(id);
      setDeleteConfirm(null);
      fetchMenuItems();
    } catch (err) {
      alert(`Failed to delete menu item: ${err.response?.data?.error || err.message}`);
      console.error('Error deleting menu item:', err);
    }
  };

  const confirmDelete = (id) => {
    setDeleteConfirm(id);
  };

  const cancelDelete = () => {
    setDeleteConfirm(null);
  };

  if (loading) {
    return (
      <div className="menu-admin-container">
        <div className="loading-spinner">
          <div className="spinner"></div>
          <p>Loading menu items...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="menu-admin-container">
      <div className="admin-header">
        <div>
          <h1>Menu Management</h1>
          <p className="admin-subtitle">Manage your restaurant menu items</p>
        </div>
        <button className="btn-create" onClick={handleCreate}>
          ➕ Create New Item
        </button>
      </div>

      {error && (
        <div className="error-banner">
          <p>❌ {error}</p>
          <button onClick={fetchMenuItems} className="btn-retry">
            Retry
          </button>
        </div>
      )}

      {menuItems.length === 0 && !error ? (
        <div className="empty-state">
          <p>No menu items yet. Create your first item!</p>
          <button className="btn-create" onClick={handleCreate}>
            Create Menu Item
          </button>
        </div>
      ) : (
        <div className="admin-menu-grid">
          {menuItems.map(item => (
            <div key={item._id} className="admin-item-wrapper">
              <MenuItemCard
                item={item}
                isAdmin={true}
                onEdit={handleEdit}
                onDelete={confirmDelete}
              />
              {deleteConfirm === item._id && (
                <div className="delete-confirmation">
                  <p>Are you sure you want to delete this item?</p>
                  <div className="delete-actions">
                    <button
                      className="btn-confirm-delete"
                      onClick={() => handleDelete(item._id)}
                    >
                      Yes, Delete
                    </button>
                    <button
                      className="btn-cancel-delete"
                      onClick={cancelDelete}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <MenuItemForm
          item={editingItem}
          onSubmit={handleFormSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingItem(null);
          }}
        />
      )}

      <div className="admin-stats">
        <p>
          Total Items: <strong>{menuItems.length}</strong> | 
          Available: <strong>{menuItems.filter(item => item.isAvailable).length}</strong> | 
          Unavailable: <strong>{menuItems.filter(item => !item.isAvailable).length}</strong>
        </p>
      </div>
    </div>
  );
};

export default MenuAdmin;

