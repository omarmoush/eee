import React, { useState, useEffect } from 'react';
import { menuAPI } from '../api/api';
import MenuItemCard from './MenuItemCard';

const MenuDisplay = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchMenuItems();
  }, []);

  const fetchMenuItems = async () => {
    try {
      setLoading(true);
      setError(null);
      const items = await menuAPI.getAllMenuItems();
      setMenuItems(items);
    } catch (err) {
      const errorMessage = err.response?.data?.error || 
                          err.message || 
                          'Failed to load menu items. Please make sure the backend server is running on port 3000.';
      setError(errorMessage);
      console.error('Error fetching menu items:', err);
      console.error('Error details:', {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
        url: err.config?.url
      });
    } finally {
      setLoading(false);
    }
  };

  // Get unique categories
  const categories = ['all', ...new Set(menuItems.map(item => item.category).filter(Boolean))];

  // Filter menu items
  const filteredItems = menuItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (loading) {
    return (
      <div className="menu-display-container">
        <div className="loading-spinner">
          <div className="spinner"></div>
          <p>Loading menu...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="menu-display-container">
        <div className="error-message">
          <p>❌ {error}</p>
          <button onClick={fetchMenuItems} className="btn-retry">
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="menu-display-container">
      <div className="menu-header">
        <h1>Our Menu</h1>
        <p className="menu-subtitle">Discover our delicious offerings</p>
      </div>

      <div className="menu-filters">
        <div className="search-box">
          <input
            type="text"
            placeholder="🔍 Search menu items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="category-filters">
          {categories.map(category => (
            <button
              key={category}
              className={`category-btn ${selectedCategory === category ? 'active' : ''}`}
              onClick={() => setSelectedCategory(category)}
            >
              {category === 'all' ? 'All Items' : category}
            </button>
          ))}
        </div>
      </div>

      {filteredItems.length === 0 ? (
        <div className="no-items-message">
          <p>No menu items found matching your criteria.</p>
        </div>
      ) : (
        <div className="menu-grid">
          {filteredItems.map(item => (
            <MenuItemCard key={item._id} item={item} />
          ))}
        </div>
      )}

      <div className="menu-stats">
        <p>
          Showing {filteredItems.length} of {menuItems.length} items
        </p>
      </div>
    </div>
  );
};

export default MenuDisplay;

