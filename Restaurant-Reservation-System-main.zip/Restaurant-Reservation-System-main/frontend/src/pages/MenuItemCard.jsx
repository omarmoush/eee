import React from 'react';
import { useNavigate } from 'react-router-dom';

const MenuItemCard = ({ item, onEdit, onDelete, isAdmin = false }) => {
  const navigate = useNavigate();

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const handleAddToCart = () => {
    const existingCart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItemIndex = existingCart.findIndex(cartItem => cartItem._id === item._id);
    if (existingItemIndex >= 0) {
      existingCart[existingItemIndex].quantity += 1;
    } else {
      existingCart.push({ ...item, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(existingCart));
    navigate('/cart');
  };

  return (
    <div className={`menu-item-card ${!item.isAvailable ? 'unavailable' : ''}`} data-cy="menu-item">
      {item.image && (
        <div className="menu-item-image">
          <img src={item.image} alt={item.name} />
        </div>
      )}
      <div className="menu-item-content">
        <div className="menu-item-header">
          <h3 className="menu-item-name">{item.name}</h3>
          <span className="menu-item-price">{formatPrice(item.price)}</span>
        </div>
        <p className="menu-item-description">{item.description}</p>
        <div className="menu-item-meta">
          {item.category && <span className="menu-item-category">{item.category}</span>}
          {item.preparationTime && <span className="menu-item-time">⏱️ {item.preparationTime} min</span>}
          {!item.isAvailable && <span className="menu-item-unavailable-badge">Unavailable</span>}
        </div>

        {isAdmin ? (
          <div className="menu-item-actions">
            <button className="btn-edit" onClick={() => onEdit(item)} data-cy="edit-menu-item">Edit</button>
            <button className="btn-delete" onClick={() => onDelete(item._id)} data-cy="delete-menu-item">Delete</button>
          </div>
        ) : (
          <div className="menu-item-actions">
            <button
              className="btn-add-to-cart"
              onClick={handleAddToCart}
              disabled={!item.isAvailable}
              aria-label="Add to cart"
              data-cy="add-to-cart"
            >
              Add to Cart
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MenuItemCard;
