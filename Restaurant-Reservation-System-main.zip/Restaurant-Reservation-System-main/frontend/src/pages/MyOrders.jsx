import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      
      // Get user ID from localStorage or decode from token
      let userId = user.id || user._id;
      if (!userId && token) {
        try {
          const payload = JSON.parse(atob(token.split('.')[1]));
          userId = payload.userId;
        } catch (e) {
          console.error('Failed to decode token:', e);
        }
      }

      if (!userId) {
        setError('Please log in to view your orders.');
        setLoading(false);
        return;
      }

      const response = await axios.get(
        `http://localhost:3000/api/v1/orders/user/${userId}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      if (response.data.success || response.data) {
        const orderData = response.data.data || response.data;
        setOrders(Array.isArray(orderData) ? orderData : []);
      }
    } catch (err) {
      console.error('Error fetching orders:', err);
      setError('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: '#FFA500',
      confirmed: '#4CAF50',
      preparing: '#2196F3',
      ready: '#9C27B0',
      completed: '#4CAF50',
      cancelled: '#F44336'
    };
    return colors[status] || '#757575';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: 'Pending',
      confirmed: 'Confirmed',
      preparing: 'Preparing',
      ready: 'Ready for Pickup',
      completed: 'Completed',
      cancelled: 'Cancelled'
    };
    return texts[status] || status;
  };

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to cancel this order?')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:3000/api/v1/orders/${orderId}`,
        { status: 'cancelled' },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      // Update local state
      setOrders(orders.map(order => 
        order._id === orderId ? { ...order, status: 'cancelled' } : order
      ));
    } catch (err) {
      console.error('Error cancelling order:', err);
      alert('Failed to cancel order. Please try again.');
    }
  };

  const filteredOrders = filterStatus === 'all' 
    ? orders 
    : orders.filter(order => order.status === filterStatus);

  if (loading) {
    return (
      <div className="my-orders-container">
        <div className="loading">Loading your orders...</div>
      </div>
    );
  }

  return (
    <div className="my-orders-container">
      <div className="my-orders-header">
        <h1>My Orders</h1>
        <button className="btn-refresh" onClick={fetchOrders}>
          Refresh
        </button>
      </div>

      {error && (
        <div className="error-banner">
          <p>{error}</p>
        </div>
      )}

      <div className="filters-container">
        <div className="filter-group">
          <label>Filter by Status:</label>
          <select 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Orders</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="preparing">Preparing</option>
            <option value="ready">Ready</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <div className="filter-stats">
          <span>Showing {filteredOrders.length} of {orders.length} orders</span>
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="no-orders">
          <h2>No orders found</h2>
          <p>Start ordering from our menu</p>
          <button className="btn-primary" onClick={() => navigate('/menu')}>
            Browse Menu
          </button>
        </div>
      ) : (
        <div className="orders-list">
          {filteredOrders.map((order) => (
            <div key={order._id} className="my-order-card">
              <div className="order-header">
                <div className="order-header-left">
                  <h3>Order #{order._id?.slice(-8)}</h3>
                  <p className="order-date">{formatDate(order.createdAt)}</p>
                </div>
                <div className="order-header-right">
                  <span 
                    className="status-badge"
                    style={{ backgroundColor: getStatusColor(order.status) }}
                  >
                    {getStatusText(order.status)}
                  </span>
                  <span 
                    className="order-type-badge"
                    style={{ 
                      backgroundColor: order.order_type === 'pickup' ? '#FF9800' : '#3F51B5',
                      color: 'white'
                    }}
                  >
                    {order.order_type === 'pickup' ? 'Pickup' : 'Dine In'}
                  </span>
                </div>
              </div>

              <div className="order-body">
                <div className="order-details-grid">
                  {order.order_type === 'pickup' && order.pickup_time && (
                    <div className="detail-item">
                      <span className="detail-label">Pickup Time:</span>
                      <span className="detail-value">{formatDate(order.pickup_time)}</span>
                    </div>
                  )}

                  {order.order_type === 'pickup' && order.contact_phone && (
                    <div className="detail-item">
                      <span className="detail-label">Contact:</span>
                      <span className="detail-value">{order.contact_phone}</span>
                    </div>
                  )}

                  {order.order_type === 'dineIn' && order.reservation_id && (
                    <div className="detail-item">
                      <span className="detail-label">Reservation:</span>
                      <span className="detail-value">{order.reservation_id}</span>
                    </div>
                  )}

                  {order.order_type === 'dineIn' && order.table_number && (
                    <div className="detail-item">
                      <span className="detail-label">Table:</span>
                      <span className="detail-value">{order.table_number}</span>
                    </div>
                  )}

                  <div className="detail-item">
                    <span className="detail-label">Payment:</span>
                    <span className="detail-value">
                      {order.payment_method === 'cash' ? 'Cash' : 'Card'}
                    </span>
                  </div>
                </div>

                <div className="order-items">
                  <h4>Items:</h4>
                  {order.menu_items?.map((item, index) => (
                    <div key={index} className="order-item-row">
                      <span className="item-name">
                        {item.menu_item?.name || 'Item'}
                      </span>
                      <span className="item-quantity">x{item.quantity}</span>
                      <span className="item-price">
                        {formatPrice((item.menu_item?.price || item.price) * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                {order.special_instructions && (
                  <div className="special-instructions">
                    <strong>Special Instructions:</strong>
                    <p>{order.special_instructions}</p>
                  </div>
                )}

                <div className="order-total">
                  <div className="total-row total-final">
                    <span>Total:</span>
                    <span>{formatPrice(
                      order.menu_items?.reduce((sum, item) => 
                        sum + ((item.menu_item?.price || item.price) * item.quantity), 0
                      ) || order.total_price
                    )}</span>
                  </div>
                </div>

                {order.status === 'pending' && (
                  <div className="order-actions">
                    <button 
                      className="btn-cancel-order"
                      onClick={() => handleCancelOrder(order._id)}
                    >
                      Cancel Order
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyOrders;
