import { useEffect, useState, useMemo } from 'react'
import axios from 'axios'
import { getNotifications, createNotification, markAsRead } from '../api/dashboard'

function Notifications() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [creating, setCreating] = useState(false)

  const [newNotif, setNewNotif] = useState({
    email: '',
    title: '',
    message: ''
  })

  // ===== AUTH =====
  const token = localStorage.getItem('token')

  const payload = useMemo(() => {
    if (!token) return null
    try {
      return JSON.parse(atob(token.split('.')[1]))
    } catch {
      return null
    }
  }, [token])

  const userId = payload?.userId
  const isAdmin = payload?.role === 'Admin'

  // ===== FETCH NOTIFICATIONS =====
  useEffect(() => {
    if (!userId) {
      setError('Missing user information. Please sign in again.')
      setLoading(false)
      return
    }

    const fetchNotifications = async () => {
      setLoading(true)
      try {
        const res = await getNotifications(userId)
        setItems(res.data.notifications || [])
        setError('')
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load notifications')
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [userId])

  // ===== CREATE NOTIFICATION (ADMIN) =====
  const handleCreate = async (e) => {
    e.preventDefault()

    if (!newNotif.email || !newNotif.title || !newNotif.message) {
      alert('Email, title, and message are required')
      return
    }

    setCreating(true)
    try {
      await createNotification({
        email: newNotif.email,
        title: newNotif.title,
        message: newNotif.message
      })

      alert('Notification sent!')
      setNewNotif({ email: '', title: '', message: '' })
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to create notification')
    } finally {
      setCreating(false)
    }
  }

  // ===== MARK AS READ =====
  const handleMarkRead = async (id) => {
    try {
      await markAsRead(id)

      setItems(prev =>
        prev.map(n => (n._id === id ? { ...n, read: true } : n))
      )
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to mark as read')
    }
  }

  // ===== DELETE =====
  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/v1/notifications/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      })

      setItems(prev => prev.filter(n => n._id !== id))
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete notification')
    }
  }

  // ===== INPUT HANDLER =====
  const handleChange = (e) => {
    const { name, value } = e.target
    setNewNotif(prev => ({ ...prev, [name]: value }))
  }

  // ===== LOADING =====
  if (loading) {
    return <div className="container">Loading notifications...</div>
  }

  return (
    <div className="container">
      <h1 className="page-title">Notifications</h1>

      {error && <div className="alert alert-error">{error}</div>}

      {/* ===== ADMIN CREATE FORM ===== */}
      {isAdmin && (
        <div className="reservation-card" style={{ marginBottom: '1.5rem' }}>
          <h2>Create Notification</h2>

          <form onSubmit={handleCreate}>
            <div className="form-group">
              <label>Email</label>
              <input
                name="email"
                value={newNotif.email}
                onChange={handleChange}
                placeholder="user@email.com"
                required
              />
            </div>

            <div className="form-group">
              <label>Title</label>
              <input
                name="title"
                value={newNotif.title}
                onChange={handleChange}
                placeholder="Notification title"
                required
              />
            </div>

            <div className="form-group">
              <label>Message</label>
              <textarea
                name="message"
                value={newNotif.message}
                onChange={handleChange}
                rows={3}
                placeholder="Notification message"
                required
              />
            </div>

            <button className="btn btn-primary" disabled={creating}>
              {creating ? 'Sending...' : 'Send Notification'}
            </button>
          </form>
        </div>
      )}

      {/* ===== NOTIFICATION LIST ===== */}
      {items.length === 0 ? (
        <div className="reservation-empty">
          <p className="card-title">No notifications yet</p>
          <p className="muted">Notifications will appear here once available.</p>
        </div>
      ) : (
        <div className="reviews-list">
          {items.map(n => (
            <div
              key={n._id}
              className={`review-card ${n.read ? 'read' : ''}`}
            >
              <div className="review-meta">
                <div>
                  <div className="review-author">
                    {n.title || 'Notification'}
                  </div>
                  <div className="review-text">{n.message}</div>
                </div>

                <span className="review-date">
                  {new Date(n.createdAt).toLocaleDateString()}
                </span>
              </div>

              <div
                className="review-actions"
                style={{
                  marginTop: '0.8rem',
                  display: 'flex',
                  gap: '0.6rem'
                }}
              >
                <button
                  className="btn-primary"
                  onClick={() => handleMarkRead(n._id)}
                  disabled={n.read}
                >
                  {n.read ? 'Read' : 'Mark as read'}
                </button>

                <button
                  className="btn-ghost"
                  onClick={() => handleDelete(n._id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default Notifications
