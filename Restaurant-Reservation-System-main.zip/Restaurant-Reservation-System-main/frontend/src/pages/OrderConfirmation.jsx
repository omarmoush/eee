import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const OrderConfirmation = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchOrder();
  }, [orderId]);

  const fetchOrder = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `http://localhost:3000/api/v1/orders/${orderId}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      if (response.data.success) {
        setOrder(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching order:', err);
      setError('Failed to load order details');
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: '#FFA500',
      confirmed: '#4CAF50',
      preparing: '#2196F3',
      ready: '#9C27B0',
      completed: '#4CAF50',
      cancelled: '#F44336'
    };
    return colors[status] || '#757575';
  };

  if (loading) {
    return (
      <div className="order-confirmation-container">
        <div className="loading">Loading order details...</div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="order-confirmation-container">
        <div className="error-banner">
          <p>❌ {error || 'Order not found'}</p>
          <button onClick={() => navigate('/menu')} className="btn-primary">
            Back to Menu
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="order-confirmation-container">
      <div className="confirmation-header">
        <div className="success-icon">✓</div>
        <h1>Order Placed Successfully!</h1>
        <p className="order-number">Order #{order._id?.slice(-8)}</p>
      </div>

      <div className="confirmation-content">
        <div className="order-details-card">
          <h2>Order Details</h2>
          
          <div className="detail-row">
            <span className="detail-label">Order Type:</span>
            <span className="detail-value">
              {order.order_type === 'pickup' ? 'Pickup' : 'Dine In'}
            </span>
          </div>

          <div className="detail-row">
            <span className="detail-label">Status:</span>
            <span 
              className="status-badge" 
              style={{ backgroundColor: getStatusColor(order.status) }}
            >
              {order.status}
            </span>
          </div>

          <div className="detail-row">
            <span className="detail-label">Payment Method:</span>
            <span className="detail-value">
              {order.payment_method === 'cash' ? 'Cash' : 'Card'}
            </span>
          </div>

          {order.order_type === 'pickup' && order.pickup_time && (
            <div className="detail-row">
              <span className="detail-label">Pickup Time:</span>
              <span className="detail-value">
                {new Date(order.pickup_time).toLocaleString()}
              </span>
            </div>
          )}

          {order.order_type === 'dineIn' && order.reservation_id && (
            <div className="detail-row">
              <span className="detail-label">Reservation ID:</span>
              <span className="detail-value">{order.reservation_id}</span>
            </div>
          )}

          {order.special_instructions && (
            <div className="detail-row">
              <span className="detail-label">Special Instructions:</span>
              <span className="detail-value">{order.special_instructions}</span>
            </div>
          )}
        </div>

        <div className="order-items-card">
          <h2>Order Items</h2>
          
          {order.menu_items?.map((item, index) => (
            <div key={index} className="order-item">
              <span className="item-name">
                {item.menu_item?.name || 'Item'} x{item.quantity}
              </span>
              <span className="item-price">
                {formatPrice((item.menu_item?.price || item.price) * item.quantity)}
              </span>
            </div>
          ))}

          <div className="summary-divider"></div>

          <div className="summary-row">
            <span>Total:</span>
            <span>{formatPrice(
              order.menu_items?.reduce((sum, item) => 
                sum + ((item.menu_item?.price || item.price) * item.quantity), 0
              ) || order.total_price
            )}</span>
          </div>
        </div>
      </div>

      <div className="confirmation-actions">
        <button 
          className="btn-primary" 
          onClick={() => navigate('/menu')}
        >
          Back to Menu
        </button>
        <button 
          className="btn-secondary" 
          onClick={() => navigate('/my-orders')}
        >
          View All Orders
        </button>
      </div>
    </div>
  );
};

export default OrderConfirmation;
