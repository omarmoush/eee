import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import axios from 'axios'

function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    role: 'Customer'
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    
    try {
      const response = await axios.post('/api/v1/users/register', formData)
      localStorage.setItem('token', response.data.token)
      navigate('/home')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container" style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '80vh' 
    }}>
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <h1 className="page-title" style={{ marginBottom: '2rem', textAlign: 'center', color: '#c8570bff' }}>
          Create Account
        </h1>
        
        <form onSubmit={handleSubmit}>
          {error && (
            <div style={{ 
              color: '#ff4444', 
              backgroundColor: '#ffeeee', 
              padding: '1rem', 
              borderRadius: '4px',
              marginBottom: '1rem',
              textAlign: 'center'
            }}>
              {error}
            </div>
          )}
          
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="Enter your full name"
              disabled={loading}
              style={{width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0'}}
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Enter your email"
              disabled={loading}
              style={{width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0'}}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Enter your password"
              disabled={loading}
              style={{width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0'}}
            />
          </div>

          <div className="form-group">
            <label htmlFor="phone">Phone</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              placeholder="Enter your phone number"
              disabled={loading}
              style={{width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0'}}
            />
          </div>

          <div className="form-group">
            <label htmlFor="role">Role</label>
            <select
              id="role"
              name="role"
              value={formData.role}
              onChange={handleChange}
              disabled={loading}
              style={{width: '100%', padding: '0.5rem', fontSize: '1rem', border: '1px solid #930101ff', borderRadius: '4px', margin: '0.5rem 0'}}

            >
              <option value="Customer">Customer</option>
              <option value="Admin">Admin</option>
            </select>
          </div>

          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ width: '100%', marginTop: '1rem' }}
            disabled={loading}
          >
            {loading ? 'Creating Account...' : 'Register'}
          </button>

          <div style={{ textAlign: 'center', marginTop: '1rem' }}>
            <p><strong>Already have an account?</strong> {' '} 
            <Link to="/" style={{ textDecoration: 'none', color: '#9a0439ff', transition: 'all 0.3s ease', textShadow: '0 0 2px #9a0439ff' }}>Login here</Link></p>
          </div>
        </form>
      </div>
    </div>
  )
}

export default Register
