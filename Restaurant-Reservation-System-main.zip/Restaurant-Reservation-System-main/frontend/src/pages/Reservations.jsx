import React, { useEffect, useMemo, useState } from 'react'
import axios from 'axios'

function decodeToken(token) {
  try {
    const base64Url = token.split('.')[1]
    if (!base64Url) return null
    // JWT uses base64url encoding — convert to base64
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
    // Pad with '=' to make length a multiple of 4
    while (base64.length % 4) base64 += '='
    return JSON.parse(atob(base64))
  } catch (err) {
    return null
  }
}

const formatDate = (value) => {
  if (!value) return ''
  const date = new Date(value)
  return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })
}

function Reservations() {
  const token = localStorage.getItem('token') || ''
  const payload = useMemo(() => (token ? decodeToken(token) : null), [token])
  const userId = payload?.userId
  const isAdmin = payload?.role === 'Admin'

  const today = new Date().toISOString().split('T')[0]

  const [formData, setFormData] = useState({
    date: today,
    time: '19:00',
    partySize: 2,
    specialRequests: '',
    contactPhone: '',
    contactEmail: ''
  })
  const [reservations, setReservations] = useState([])
  const [loading, setLoading] = useState(false)
  const [listLoading, setListLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [editingId, setEditingId] = useState(null)

  useEffect(() => {
    if (!userId) return
    loadReservations()
  }, [userId])

  const loadReservations = async () => {
    // Allow admins to fetch all reservations; customers fetch their own
    if (!isAdmin && !userId) return
    setListLoading(true)
    setError('')
    try {
      const url = isAdmin ? '/api/v1/reservations' : `/api/v1/reservations/user/${userId}`
      const res = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` }
      })
      setReservations(res.data?.data || [])
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load your reservations.')
    } finally {
      setListLoading(false)
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'partySize' ? Number(value) : value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    console.log('Reservations: submit clicked', { formData, userId, isAdmin })
    if (!userId) {
      setError('Missing user details. Please sign in again.')
      return
    }
    if (isAdmin) {
      setError('Admins can only approve or reject reservations.')
      return
    }
    setLoading(true)
    try {
      if (editingId) {
        // Customer updating an existing reservation
        await axios.put(`/api/v1/reservations/${editingId}`, {
          ...formData
        }, {
          headers: { Authorization: `Bearer ${token}` }
        })
        setSuccess('Reservation updated.')
      } else {
        // Customer creating a new reservation
        await axios.post('/api/v1/reservations', {
          ...formData,
          user_id: userId
        }, {
          headers: { Authorization: `Bearer ${token}` }
        })
        setSuccess('Reservation submitted.')
      }
      setFormData((prev) => ({ ...prev, date: today, time: '19:00', partySize: 2, specialRequests: '' }))
      setEditingId(null)
      loadReservations()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not submit reservation.')
    } finally {
      setLoading(false)
    }
  }

  const updateStatus = async (id, status) => {
    setError('')
    setSuccess('')
    try {
      await axios.put(`/api/v1/reservations/${id}`, { status }, {
        headers: { Authorization: `Bearer ${token}` }
      })
      setSuccess(status === 'confirmed' ? 'Reservation approved.' : status === 'cancelled' ? 'Reservation cancelled.' : 'Status updated.')
      loadReservations()
    } catch (err) {
      setError(err.response?.data?.message || 'Could not update this reservation.')
    }
  }

  const startEdit = (reservation) => {
    const dateValue = reservation.date ? new Date(reservation.date).toISOString().split('T')[0] : today
    setFormData({
      date: dateValue,
      time: reservation.time,
      partySize: reservation.partySize,
      specialRequests: reservation.specialRequests || '',
      contactPhone: reservation.contactPhone || '',
      contactEmail: reservation.contactEmail || ''
    })
    setEditingId(reservation._id)
    setError('')
    setSuccess('Editing your reservation.')
  }

  const cancelEdit = () => {
    setFormData({
      date: today,
      time: '19:00',
      partySize: 2,
      specialRequests: '',
      contactPhone: '',
      contactEmail: ''
    })
    setEditingId(null)
  }

  return (
    <div className="container">
      <section className="reservation-hero">
        <div>
          <p className="eyebrow">Reservations</p>
          <h1 className="page-title">Reserve a table</h1>
          <p className="page-subtitle">Send your preferred date, time, and party size. The team will confirm with you.</p>
        </div>
        <div className="reservation-meta-card">
          <p className="meta-title">Signed in</p>
          <p className="meta-value">{payload?.role || 'Guest'}</p>
          <p className="meta-sub">Token bound user: {userId || 'unknown'}</p>
        </div>
      </section>

      <div className="reservation-grid">
        {!isAdmin && (
          <div className="reservation-card">
            <div className="card-header">
              <div>
                <p className="eyebrow">{editingId ? 'Update request' : 'New request'}</p>
                <h2 className="card-title">{editingId ? 'Update your reservation' : 'Request a table'}</h2>
              </div>
              <div className="action-buttons">
                {editingId && (
                  <button type="button" className="btn-ghost" onClick={cancelEdit}>
                    Cancel edit
                  </button>
                )}
                <button type="button" className="btn-ghost" onClick={loadReservations} disabled={listLoading}>
                  {listLoading ? 'Refreshing...' : 'Refresh'}
                </button>
              </div>
            </div>

            {error && <div className="alert alert-error">{error}</div>}
            {success && <div className="alert alert-success">{success}</div>}

            <form className="reservation-form" onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="date">Date</label>
                  <input id="date" name="date" type="date" value={formData.date} min={today} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label htmlFor="time">Time</label>
                  <input id="time" name="time" type="time" value={formData.time} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label htmlFor="partySize">Party size</label>
                  <input id="partySize" name="partySize" type="number" min="1" value={formData.partySize} onChange={handleChange} required />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="contactPhone">Phone</label>
                  <input id="contactPhone" name="contactPhone" type="tel" value={formData.contactPhone} onChange={handleChange} required />
                </div>
                <div className="form-group">
                  <label htmlFor="contactEmail">Email</label>
                  <input id="contactEmail" name="contactEmail" type="email" value={formData.contactEmail} onChange={handleChange} required />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="specialRequests">Notes</label>
                <textarea id="specialRequests" name="specialRequests" rows="4" value={formData.specialRequests} onChange={handleChange} placeholder="Allergies, occasion, seating preference" />
              </div>

              <div className="form-actions">
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? 'Submitting...' : 'Submit reservation'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="reservation-card">
          <div className="card-header">
            <div>
              <p className="eyebrow">Your reservations</p>
              <h2 className="card-title">Latest</h2>
            </div>
            <button type="button" className="btn-ghost" onClick={loadReservations} disabled={listLoading}>
              {listLoading ? 'Refreshing...' : 'Refresh'}
            </button>
          </div>

          {listLoading ? (
            <p className="muted">Loading reservations...</p>
          ) : reservations.length === 0 ? (
            <div className="reservation-empty">
              <p className="card-title">No reservations yet</p>
              <p className="muted">Submit a request to see it listed here.</p>
            </div>
          ) : (
            <div className="reservation-list">
              {reservations.map((reservation) => (
                <div key={reservation._id} className="reservation-row">
                  <div className="reservation-meta">
                    <div>
                      <p className="reservation-date">{formatDate(reservation.date)} at {reservation.time}</p>
                      <p className="muted">Party of {reservation.partySize}</p>
                    </div>
                    <div className="reservation-status">
                      <span className={`status-chip status-${reservation.status || 'pending'}`}>{reservation.status || 'pending'}</span>
                    </div>
                  </div>
                  {reservation.specialRequests && <p className="muted">Note: {reservation.specialRequests}</p>}
                  {!isAdmin && (
                    <p className="reservation-id"><strong>Reservation ID:</strong> {reservation._id}</p>
                  )}
                  <div className="reservation-actions">
                    <div className="reservation-contact">
                      <span>{reservation.contactPhone}</span>
                      <span className="dot" />
                      <span>{reservation.contactEmail}</span>
                    </div>
                    <div className="action-buttons">
                      {!isAdmin && reservation.status === 'pending' && (
                        <>
                          <button
                            type="button"
                            className="btn-ghost"
                            onClick={() => startEdit(reservation)}
                          >
                            Update
                          </button>
                          <button
                            type="button"
                            className="btn-ghost"
                            onClick={() => updateStatus(reservation._id, 'cancelled')}
                          >
                            Cancel
                          </button>
                        </>
                      )}
                      {isAdmin && reservation.status === 'pending' && (
                        <>
                          <button type="button" className="btn-ghost" onClick={() => updateStatus(reservation._id, 'confirmed')}>
                            Approve
                          </button>
                          <button type="button" className="btn-ghost" onClick={() => updateStatus(reservation._id, 'cancelled')}>
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Reservations
export { decodeToken, formatDate }


