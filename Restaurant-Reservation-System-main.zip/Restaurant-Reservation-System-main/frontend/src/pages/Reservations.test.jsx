import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import Reservations from './Reservations.jsx';
import { decodeToken, formatDate } from './Reservations.jsx';
import axios from 'axios';

//all are mocks BTW!
jest.mock('axios');

const localStorageMock = (() => {
  let store = {};
  return {
    getItem: jest.fn((key) => store[key] || null),
    setItem: jest.fn((key, value) => { store[key] = value.toString(); }),
    clear: jest.fn(() => { store = {}; }),
    removeItem: jest.fn((key) => { delete store[key]; })
  };
})();
Object.defineProperty(window, 'localStorage', { value: localStorageMock });

const sampleTokenPayload = { userId: '123', role: 'Customer' };
function encodeToken(payload) {
  const base64 = btoa(JSON.stringify(payload));
  return `header.${base64}.signature`;
}

describe('Reservations Page', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.setItem('token', encodeToken(sampleTokenPayload));
  });

  describe('decodeToken', () => {
    test('decodes a valid token correctly', () => {
      const base64 = btoa(JSON.stringify({ userId: '1', role: 'Customer' }));
      const token = `header.${base64}.signature`;
      expect(decodeToken(token)).toEqual({ userId: '1', role: 'Customer' });
    });

    test('returns null for invalid token', () => {
      expect(decodeToken('invalid.token')).toBeNull();
      expect(decodeToken('')).toBeNull();
      expect(decodeToken(null)).toBeNull();
    });
  });

  describe('formatDate', () => {
    test('formats a valid date correctly', () => {
      const dateStr = '2025-12-25T12:00:00Z';
      const formatted = formatDate(dateStr);
      expect(formatted).toMatch(/2025/);
    });

    test('returns empty string for null or undefined', () => {
      expect(formatDate(null)).toBe('');
      expect(formatDate(undefined)).toBe('');
    });
  });

  test('renders reservation form and list', () => {
    render(<Reservations />);
    expect(screen.getByText(/Reserve a table/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Date/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Time/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Party size/i)).toBeInTheDocument();
  });

  test('handles form input changes', () => {
    render(<Reservations />);
    const dateInput = screen.getByLabelText(/Date/i);
    const partyInput = screen.getByLabelText(/Party size/i);
    fireEvent.change(dateInput, { target: { value: '2025-12-25' } });
    fireEvent.change(partyInput, { target: { value: '4' } });
    expect(dateInput.value).toBe('2025-12-25');
    expect(partyInput.value).toBe('4');
  });

  test('submits new reservation successfully', async () => {
    axios.post.mockResolvedValueOnce({ data: {} });
    axios.get.mockResolvedValueOnce({ data: { data: [] } });

    render(<Reservations />);

    fireEvent.change(screen.getByLabelText(/Date/i), { target: { value: '2025-12-20' } });
    fireEvent.change(screen.getByLabelText(/Time/i), { target: { value: '19:00' } });
    fireEvent.change(screen.getByLabelText(/Party size/i), { target: { value: '2' } });
    fireEvent.change(screen.getByLabelText(/Phone/i), { target: { value: '1234567890' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'test@example.com' } });

    fireEvent.click(screen.getByText(/Submit reservation/i));

    await waitFor(() => {
      expect(axios.post).toHaveBeenCalledWith(
        '/api/v1/reservations',
        expect.objectContaining({ user_id: '123' }),
        expect.any(Object)
      );
      expect(screen.getByText(/Reservation submitted/i)).toBeInTheDocument();
    });
  });

  test('shows error if userId missing', async () => {
    localStorage.setItem('token', encodeToken({ role: 'Customer' })); // no userId
    render(<Reservations />);

    fireEvent.change(screen.getByLabelText(/Date/i), { target: { value: '2025-12-20' } });
    fireEvent.change(screen.getByLabelText(/Time/i), { target: { value: '19:00' } });
    fireEvent.change(screen.getByLabelText(/Party size/i), { target: { value: '2' } });
    fireEvent.change(screen.getByLabelText(/Phone/i), { target: { value: '1234567890' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'test@example.com' } });

    fireEvent.click(screen.getByText(/Submit reservation/i));

    await waitFor(() => {
      expect(screen.getByText(/Missing user details/i)).toBeInTheDocument();
    });
  });

  test('loads reservations and displays them', async () => {
    const reservationsMock = [
      { _id: '1', date: '2025-12-20', time: '19:00', partySize: 2, status: 'pending', contactPhone: '123', contactEmail: 'a@b.com', specialRequests: 'None' }
    ];
    axios.get.mockResolvedValueOnce({ data: { data: reservationsMock } });

    render(<Reservations />);

    await waitFor(() => {
      expect(screen.getByText(/20 Dec 2025 at 19:00/i)).toBeInTheDocument();
      expect(screen.getByText(/Party of 2/i)).toBeInTheDocument();
      expect(screen.getByText(/None/i)).toBeInTheDocument();
    });
  });

  test('starts editing a reservation', async () => {
    const reservationsMock = [
      { _id: '1', date: '2025-12-20', time: '19:00', partySize: 2, status: 'pending', contactPhone: '123', contactEmail: 'a@b.com', specialRequests: 'None' }
    ];
    axios.get.mockResolvedValueOnce({ data: { data: reservationsMock } });

    render(<Reservations />);
    await waitFor(() => {
      const updateButtons = screen.getAllByText(/^Update$/i); // match only button text
      fireEvent.click(updateButtons[0]);
      expect(screen.getByDisplayValue('2025-12-20')).toBeInTheDocument();
      expect(screen.getByDisplayValue('19:00')).toBeInTheDocument();
    });
  });
});
