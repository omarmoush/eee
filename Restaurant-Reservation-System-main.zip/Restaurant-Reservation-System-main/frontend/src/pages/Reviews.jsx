import { useState, useEffect } from 'react'
import { getReviews, createReview, updateReview, deleteReview } from '../api/api'
import axios from 'axios'

function Reviews() {
  const [reviews, setReviews] = useState([])
  const [reservations, setReservations] = useState([])
  const [formData, setFormData] = useState({
    reservation_id: '',
    rating: 5,
    comment: ''
  })
  const [editingId, setEditingId] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [userRole, setUserRole] = useState('')
  const [userId, setUserId] = useState('')
  const [isAuthed, setIsAuthed] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]))
      setUserRole(payload.role)
      setUserId(payload.userId)
      setIsAuthed(true)
    }
    fetchReviews()
    fetchReservations()
  }, [])

  const fetchReservations = async () => {
    const token = localStorage.getItem('token')
    if (!token) return
    
    try {
      // Decode token to get user ID
      const payload = JSON.parse(atob(token.split('.')[1]))
      const userId = payload.userId
      
      const response = await axios.get(`/api/v1/reservations/user/${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const allReservations = response.data.data || response.data
      
      // Get all reviews to filter out reservations that already have reviews
      const reviewsResponse = await getReviews()
      const reviewedReservationIds = reviewsResponse.data
        .filter(review => review.reservation_id)
        .map(review => review.reservation_id._id || review.reservation_id)
      
      // Filter out reservations that already have reviews
      const availableReservations = allReservations.filter(
        reservation => !reviewedReservationIds.includes(reservation._id)
      )
      
      setReservations(availableReservations)
    } catch (err) {
      console.error('Failed to fetch reservations:', err)
    }
  }

  const fetchReviews = async () => {
    try {
      setLoading(true)
      const response = await getReviews()
      setReviews(response.data)
      setError('')
    } catch (err) {
      console.error('Failed to fetch reviews:', err)
      setError('Failed to load reviews')
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const payload = { ...formData, rating: Number(formData.rating) }

    try {
      if (editingId) {
        await updateReview(editingId, payload)
        alert('Review updated successfully!')
        setEditingId(null)
      } else {
        await createReview(payload)
        alert('Review submitted successfully!')
      }
      setFormData({ reservation_id: '', rating: 5, comment: '' })
      fetchReviews()
      fetchReservations() // Refresh to update available reservations
    } catch (err) {
      alert(err.response?.data?.message || err.response?.data?.error || 'Failed to submit review')
    }
  }

  const handleEdit = (review) => {
    setEditingId(review._id)
    setFormData({
      reservation_id: review.reservation_id?._id || review.reservation_id || '',
      rating: review.rating,
      comment: review.comment || ''
    })
  }

  const handleDelete = async (reviewId) => {
    if (!confirm('Are you sure you want to delete this review?')) return
    
    try {
      await deleteReview(reviewId)
      alert('Review deleted successfully!')
      fetchReservations() // Refresh to show the reservation again
      fetchReviews()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete review')
    }
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setFormData({ reservation_id: '', rating: 5, comment: '' })
  }

  const canEditDelete = (review) => {
    return review.user_id?._id === userId || review.user_id === userId
  }

  if (loading) {
    return <div className="container">Loading reviews...</div>
  }

  return (
    <div className="container">
      <div className="reviews-header">
        <h1 className="page-title">Reviews</h1>
      </div>
      {error && <div style={{ color: 'red', marginBottom: '1rem' }}>{error}</div>}

      {!isAuthed && (
        <p style={{ marginBottom: '1rem', color: '#5b4a3d' }}>Sign in to share your story. Everyone can still read the latest notes from guests.</p>
      )}

      {isAuthed && (
        <div className="review-form">
          <div className="review-form__header">
            <div>
              <h2>{editingId ? 'Edit your review' : 'Share your experience'}</h2>
              <p className="subtle">Pick your reservation, tap a star rating, and leave a note.</p>
            </div>
            {editingId && (
              <button onClick={handleCancelEdit} className="text-button">Clear edit</button>
            )}
          </div>
          <form onSubmit={handleSubmit} className="review-form__grid">
            <div className="form-group">
              <label htmlFor="reservation_id">Reservation</label>
              <select
                id="reservation_id"
                name="reservation_id"
                value={formData.reservation_id}
                onChange={handleChange}
                required
              >
                <option value="">Select a reservation</option>
                {reservations.map((reservation) => (
                  <option key={reservation._id} value={reservation._id}>
                    {new Date(reservation.date).toLocaleDateString()} at {reservation.time} · Party of {reservation.partySize}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Rating</label>
              <div className="star-picker">
                {[1,2,3,4,5].map((star) => (
                  <button
                    type="button"
                    key={star}
                    className={`star ${star <= formData.rating ? 'star--active' : ''}`}
                    onClick={() => setFormData({ ...formData, rating: star })}
                    aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>

            <div className="form-group form-group--full">
              <label htmlFor="comment">Your notes</label>
              <textarea
                id="comment"
                name="comment"
                value={formData.comment}
                onChange={handleChange}
                rows="4"
                placeholder="Tell us about your visit..."
              />
            </div>

            <div className="review-form__actions">
              <button type="submit" className="btn btn-primary">
                {editingId ? 'Update Review' : 'Submit Review'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="reviews-list">
        {reviews.length === 0 ? (
          <p>No reviews yet.</p>
        ) : (
          reviews.map((review) => (
            <div key={review._id} className="review-card">
              <div className="review-meta">
                <div>
                  <div className="review-author">{review.user_id?.name || review.user?.name || 'Anonymous'}</div>
                  <div className="review-stars">{'★'.repeat(review.rating)}</div>
                  {canEditDelete(review) && (
                    <div className="review-actions-inline">
                      <button onClick={() => handleEdit(review)} className="text-button">Edit</button>
                      <button onClick={() => handleDelete(review._id)} className="text-button">Delete</button>
                    </div>
                  )}
                </div>
                <span className="review-date">{new Date(review.createdAt).toLocaleDateString()}</span>
              </div>
              <p className="review-text">{review.comment || '—'}</p>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default Reviews
